import { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, AlertCircle, Lock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';

export function AdminLoginPage() {
  const { firebaseUser, role, loginWithEmail, loginWithGoogle, logout } = useAuth();
  const { language } = useData();
  const navigate = useNavigate();
  const isBn = language === 'bn';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (firebaseUser && role === 'admin') {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <ShieldCheck className="w-10 h-10 text-blue-700 mx-auto" />
        <h1 className="font-display text-2xl font-bold">
          {isBn ? 'অ্যাডমিন সেশন সক্রিয় আছে' : 'Admin Session Active'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">{firebaseUser.email}</p>
        <div className="flex justify-center gap-3">
          <button
            type="button"
            onClick={() => navigate('/admin/dashboard')}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            {isBn ? 'অ্যাডমিন ড্যাশবোর্ডে প্রবেশ করুন' : 'Open Admin Dashboard'}
          </button>
          <button
            type="button"
            onClick={() => void logout()}
            className="px-4 py-2.5 text-sm font-medium border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer"
          >
            {isBn ? 'লগআউট' : 'Logout'}
          </button>
        </div>
      </div>
    );
  }

  async function handleEmailLogin(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const resolved = await loginWithEmail(email, password);
      if (resolved === 'admin') {
        navigate('/admin/dashboard');
      } else {
        setError(
          isBn
            ? 'এই অ্যাকাউন্টটির অ্যাডমিন অনুমোদন নেই। সাধারণ ইউজাররা অ্যাডমিন প্যানেলে প্রবেশ করতে পারবেন না।'
            : 'Access denied. This account does not have Administrator privileges.'
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogleAdminLogin() {
    setError(null);
    setBusy(true);
    try {
      const resolved = await loginWithGoogle();
      if (resolved === 'admin') {
        navigate('/admin/dashboard');
      } else {
        setError(
          isBn
            ? 'এই Google অ্যাকাউন্টটি Firestore admins কালেকশনে অনুমোদিত নয়।'
            : 'This Google account is not authorized in the Firestore admins registry.'
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950/60 flex items-center justify-center text-blue-700 dark:text-blue-400">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Dial for Health Admin
            </h1>
            <p className="text-xs text-slate-500">
              {isBn ? 'সুরক্ষিত ভূমিকা-ভিত্তিক অ্যাডমিন লগইন' : 'Role-Verified Administrator Access'}
            </p>
          </div>
        </div>

        {firebaseUser && role === 'user' && (
          <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 space-y-2">
            <p>
              {isBn
                ? `আপনি বর্তমানে সাধারণ ইউজার (${firebaseUser.email || firebaseUser.phoneNumber}) হিসেবে লগইন আছেন। অ্যাডমিন প্রবেশের জন্য অনুমোদিত অ্যাডমিন অ্যাকাউন্ট দিয়ে লগইন করুন।`
                : 'Currently signed in as a regular user. Sign out and authenticate with an authorized administrator account.'}
            </p>
            <button
              type="button"
              onClick={() => void logout()}
              className="underline font-semibold cursor-pointer"
            >
              {isBn ? 'বর্তমান অ্যাকাউন্ট থেকে লগআউট করুন' : 'Sign out current account'}
            </button>
          </div>
        )}

        {error && (
          <div
            role="alert"
            className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-xs text-red-800 dark:text-red-300"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <button
          type="button"
          disabled={busy}
          onClick={handleGoogleAdminLogin}
          className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
        >
          {isBn ? 'অনুমোদিত Google অ্যাডমিন দিয়ে প্রবেশ করুন' : 'Sign in with Authorized Google Admin'}
        </button>

        <div className="relative flex items-center justify-center text-xs text-slate-400">
          <span className="w-full border-t border-slate-200 dark:border-slate-800" />
          <span className="px-3 bg-white dark:bg-slate-900 whitespace-nowrap">
            {isBn ? 'অথবা ইমেইল ও পাসওয়ার্ড' : 'OR Email & Password'}
          </span>
          <span className="w-full border-t border-slate-200 dark:border-slate-800" />
        </div>

        <form onSubmit={handleEmailLogin} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium mb-1">
              {isBn ? 'অ্যাডমিন ইমেইল' : 'Admin Email'}
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@dialforhealth.bd"
              className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">
              {isBn ? 'পাসওয়ার্ড' : 'Password'}
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 rounded-lg cursor-pointer"
          >
            {busy ? (isBn ? 'যাচাই হচ্ছে...' : 'Verifying...') : isBn ? 'অ্যাডমিন লগইন' : 'Admin Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
}
