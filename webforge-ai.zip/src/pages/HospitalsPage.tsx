import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Heart, MapPin, PhoneCall, ExternalLink, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { toggleFavoriteItem } from '../services/firestoreService';
import { Hospital } from '../types/healthcare';
import { AdBannerSlot } from '../components/AdBannerSlot';
import { ResilientImage } from '../components/ResilientImage';

interface HospitalsPageProps {
  onOpenAuth: () => void;
}

export function HospitalsPage({ onOpenAuth }: HospitalsPageProps) {
  const { firebaseUser, userProfile } = useAuth();
  const { hospitals, doctors, language } = useData();
  const [searchParams, setSearchParams] = useSearchParams();
  const isBn = language === 'bn';

  const [queryText, setQueryText] = useState('');
  const [locationFilter, setLocationFilter] = useState('all');
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);

  const published = hospitals.filter((h) => h.published);
  const locations = Array.from(new Set(published.map((h) => h.location).filter(Boolean)));

  useEffect(() => {
    const idParam = searchParams.get('id');
    if (idParam) {
      const found = published.find((h) => h.id === idParam);
      if (found) setSelectedHospital(found);
    }
  }, [searchParams, hospitals]);

  const filtered = published.filter((h) => {
    const q = queryText.trim().toLowerCase();
    const matchesQ =
      !q ||
      h.name.toLowerCase().includes(q) ||
      (h.nameEn || '').toLowerCase().includes(q) ||
      h.location.toLowerCase().includes(q) ||
      (h.departments || []).some((d) => d.toLowerCase().includes(q)) ||
      (h.diagnosticServices || []).some((s) => s.toLowerCase().includes(q));
    const matchesLoc = locationFilter === 'all' || h.location === locationFilter;
    return matchesQ && matchesLoc;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'হাসপাতাল ডিরেক্টরি' : 'Hospital Directory'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          {isBn
            ? 'নাম, এলাকা ও চিকিৎসা সেবা অনুযায়ী বাংলাদেশের হাসপাতাল খুঁজুন'
            : 'Search verified hospitals by name, city, and available medical services'}
        </p>
      </div>

      <AdBannerSlot placement="hospital_banner" />

      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl grid sm:grid-cols-3 gap-3">
        <div className="relative sm:col-span-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder={isBn ? 'হাসপাতালের নাম, বিভাগ বা সেবা খুঁজুন...' : 'Hospital name, department, or service...'}
            className="w-full min-h-[42px] pl-9 pr-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
        </div>
        <select
          value={locationFilter}
          onChange={(e) => setLocationFilter(e.target.value)}
          className="min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
        >
          <option value="all">{isBn ? 'সকল শহর' : 'All Cities'}</option>
          {locations.map((loc) => (
            <option key={loc} value={loc}>
              {loc}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="p-10 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center text-sm text-slate-500">
          {isBn ? 'কোনো হাসপাতাল পাওয়া যায়নি।' : 'No hospitals matched your search.'}
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((h) => {
            const isFav = userProfile?.favoriteHospitalIds?.includes(h.id) ?? false;
            return (
              <article
                key={h.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-[16/10] bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-800">
                    <ResilientImage
                      src={h.imageUrl}
                      alt={h.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="text-xs text-slate-500">
                        {h.location} {h.emergencyPhone ? `· জরুরি: ${h.emergencyPhone}` : ''}
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          if (!firebaseUser) {
                            onOpenAuth();
                            return;
                          }
                          void toggleFavoriteItem(firebaseUser.uid, 'hospital', h.id, isFav);
                        }}
                        className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-red-600 text-red-600' : ''}`} />
                      </button>
                    </div>
                    <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                      {h.name}
                    </h2>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 flex items-start gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-blue-700 shrink-0 mt-0.5" />
                      <span>{h.address}</span>
                    </p>
                    {h.departments && h.departments.length > 0 && (
                      <p className="text-xs text-slate-500 mt-3">
                        {h.departments.slice(0, 4).join(' · ')}
                      </p>
                    )}
                  </div>
                </div>

                <div className="px-5 pb-5 flex items-center justify-between gap-3 border-t border-slate-100 dark:border-slate-800 pt-3">
                  <a
                    href={`tel:${h.contactPhone}`}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 tabular-nums"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-blue-700" />
                    <span>{h.contactPhone}</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => setSelectedHospital(h)}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                  >
                    {isBn ? 'বিস্তারিত' : 'Details'}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Hospital Detail Modal */}
      {selectedHospital && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
          onClick={() => {
            setSelectedHospital(null);
            setSearchParams({});
          }}
        >
          <div
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl p-6 space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <p className="text-xs text-blue-700 dark:text-blue-400 font-medium">
                  {selectedHospital.location} · {selectedHospital.visitingHours || '২৪ ঘণ্টা'}
                </p>
                <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                  {selectedHospital.name}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">{selectedHospital.address}</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedHospital(null);
                  setSearchParams({});
                }}
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedHospital.description && (
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedHospital.description}
              </p>
            )}

            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <p className="text-xs text-slate-500 mb-1">{isBn ? 'বিভাগসমূহ' : 'Departments'}</p>
                <p className="text-sm font-medium">
                  {(selectedHospital.departments || []).join(', ') || '—'}
                </p>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <p className="text-xs text-slate-500 mb-1">{isBn ? 'সুযোগ-সুবিধা ও ডায়াগনস্টিক' : 'Facilities & Diagnostics'}</p>
                <p className="text-sm font-medium">
                  {[
                    ...(selectedHospital.medicalFacilities || []),
                    ...(selectedHospital.diagnosticServices || []),
                  ].join(', ') || '—'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-2">
              <a
                href={`tel:${selectedHospital.contactPhone}`}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg tabular-nums"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>{selectedHospital.contactPhone}</span>
              </a>
              {selectedHospital.emergencyPhone && (
                <a
                  href={`tel:${selectedHospital.emergencyPhone}`}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-red-700 rounded-lg tabular-nums"
                >
                  <span>{isBn ? 'জরুরি:' : 'Emergency:'} {selectedHospital.emergencyPhone}</span>
                </a>
              )}
              {selectedHospital.mapUrl && (
                <a
                  href={selectedHospital.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium border border-slate-300 dark:border-slate-700 rounded-lg"
                >
                  <span>Google Maps</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>

            {/* Associated Doctors */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <h3 className="font-display font-bold text-base mb-2">
                {isBn ? 'এই হাসপাতালের ডাক্তারবৃন্দ' : 'Doctors at this Hospital'}
              </h3>
              <div className="space-y-2">
                {doctors
                  .filter((d) => d.hospitalName === selectedHospital.name && d.active)
                  .map((d) => (
                    <div key={d.id} className="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0">
                      <span>{d.name} ({d.department})</span>
                      <span className="font-medium text-blue-700 dark:text-blue-400 tabular-nums">
                        ৳ {d.consultationFee}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
