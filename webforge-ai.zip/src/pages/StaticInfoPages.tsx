import { useState, FormEvent } from 'react';
import { PhoneCall, Mail, MapPin, CheckCircle2 } from 'lucide-react';
import { useData } from '../contexts/DataContext';

export function AboutPage() {
  const { appSettings, language } = useData();
  const isBn = language === 'bn';
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
      <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
        {isBn ? 'Dial for Health সম্পর্কে' : 'About Dial for Health'}
      </h1>
      <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">
        {appSettings.aboutContent}
      </p>
      <div className="grid sm:grid-cols-3 gap-4 pt-4">
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
          <h2 className="font-display font-bold text-base mb-1">
            {isBn ? 'নির্ভরযোগ্য ডাক্তার ডিরেক্টরি' : 'Verified Doctors'}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {isBn ? 'যোগ্যতা, চেম্বার ও প্রকৃত ভিজিটিং ফি সহ যাচাইকৃত তথ্য।' : 'Verified qualifications, chambers, and consultation fees.'}
          </p>
        </div>
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
          <h2 className="font-display font-bold text-base mb-1">
            {isBn ? 'ডাবল-বুকিং সুরক্ষা' : 'Double-Booking Lock'}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {isBn ? 'ফায়ারবেস ট্রানজেকশনের মাধ্যমে প্রতিটি স্লটের সুরক্ষা।' : 'Atomic Firestore transactions prevent duplicate slot bookings.'}
          </p>
        </div>
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
          <h2 className="font-display font-bold text-base mb-1">
            {isBn ? 'দেশব্যাপী হাসপাতাল তথ্য' : 'Hospital Network'}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {isBn ? 'ঢাকা, চট্টগ্রামসহ সারা দেশের হাসপাতাল ও জরুরি নম্বর।' : 'Hospitals, diagnostic centers, and emergency contacts nationwide.'}
          </p>
        </div>
      </div>
    </div>
  );
}

export function ContactPage() {
  const { appSettings, language } = useData();
  const isBn = language === 'bn';
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (name.trim().length < 2 || message.trim().length < 5) return;
    setSent(true);
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid md:grid-cols-12 gap-8">
      <div className="md:col-span-5 space-y-4">
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'যোগাযোগ ও সাপোর্ট' : 'Contact Support'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          {isBn
            ? 'অ্যাপয়েন্টমেন্ট সহায়তা, হাসপাতাল তালিকাভুক্তি বা বিজ্ঞাপনের জন্য সরাসরি যোগাযোগ করুন।'
            : 'Reach out for appointment help, hospital onboarding, or healthcare promotions.'}
        </p>
        <div className="space-y-3 pt-2 text-sm text-slate-700 dark:text-slate-300">
          <p className="flex items-center gap-2 tabular-nums">
            <PhoneCall className="w-4 h-4 text-blue-700" />
            <span>{appSettings.supportPhone}</span>
          </p>
          <p className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-blue-700" />
            <span>{appSettings.supportEmail}</span>
          </p>
          <p className="flex items-start gap-2">
            <MapPin className="w-4 h-4 text-blue-700 mt-0.5" />
            <span>{appSettings.address}</span>
          </p>
        </div>
      </div>

      <div className="md:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
        {sent ? (
          <div className="flex items-start gap-3 py-6">
            <CheckCircle2 className="w-6 h-6 text-emerald-700 shrink-0" />
            <div>
              <h2 className="font-display font-bold text-lg">
                {isBn ? 'বার্তা প্রেরিত হয়েছে' : 'Message Received'}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                {isBn
                  ? 'আমাদের সাপোর্ট টিম দ্রুত আপনার সাথে যোগাযোগ করবে।'
                  : 'Our support team will respond shortly.'}
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium mb-1">
                {isBn ? 'আপনার নাম' : 'Your Name'}
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">
                {isBn ? 'মোবাইল নম্বর বা ইমেইল' : 'Mobile Number or Email'}
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">
                {isBn ? 'বার্তা' : 'Message'}
              </label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
            >
              {isBn ? 'বার্তা পাঠান' : 'Send Message'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

export function PolicyPage({ mode }: { mode: 'privacy' | 'terms' | 'faq' }) {
  const { appSettings, language } = useData();
  const isBn = language === 'bn';

  if (mode === 'faq') {
    const faqs = [
      {
        q: isBn ? 'কীভাবে অনলাইনে ডাক্তার অ্যাপয়েন্টমেন্ট নেব?' : 'How do I book a doctor appointment?',
        a: isBn
          ? 'ডাক্তার তালিকা থেকে পছন্দের চিকিৎসক বেছে নিয়ে তারিখ ও সময় স্লট নির্বাচন করুন এবং রোগীর তথ্য দিয়ে জমা দিন।'
          : 'Select your preferred specialist, choose an open date and time slot, and submit patient details.',
      },
      {
        q: isBn ? 'একই সময়ে কি দুজন রোগী একই স্লট বুক করতে পারবেন?' : 'Can two patients book the exact same slot?',
        a: isBn
          ? 'না। প্রতিটি স্লট Firestore Atomic Transaction দ্বারা সুরক্ষিত, তাই একবার বুক হলে ওই সময়টি স্বয়ংক্রিয়ভাবে লক হয়ে যায়।'
          : 'No. Every slot uses an atomic Firestore transaction lock to guarantee zero double bookings.',
      },
      {
        q: isBn ? 'অ্যাপয়েন্টমেন্ট বাতিল করা যাবে কি?' : 'Can I cancel an appointment?',
        a: isBn
          ? 'হ্যাঁ, ইউজার ড্যাশবোর্ড (/dashboard) থেকে অপেক্ষমাণ বা নিশ্চিত অ্যাপয়েন্টমেন্ট বাতিল করা যায়।'
          : 'Yes, pending or confirmed appointments can be cancelled directly from your User Dashboard.',
      },
    ];

    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'সচরাচর জিজ্ঞাসা (FAQ)' : 'Frequently Asked Questions'}
        </h1>
        <div className="space-y-4">
          {faqs.map((item) => (
            <div
              key={item.q}
              className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
            >
              <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
                {item.q}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                {item.a}
              </p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-4">
      <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
        {mode === 'privacy'
          ? isBn
            ? 'গোপনীয়তা নীতি (Privacy Policy)'
            : 'Privacy Policy'
          : isBn
          ? 'ব্যবহারের শর্তাবলি (Terms & Conditions)'
          : 'Terms & Conditions'}
      </h1>
      <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
        {mode === 'privacy' ? appSettings.privacyContent : appSettings.termsContent}
      </p>
    </div>
  );
}
