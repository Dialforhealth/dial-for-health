import { useState } from 'react';
import { Calendar, ArrowRight } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Doctor } from '../types/healthcare';

interface AppointmentsPageProps {
  onBookDoctor: (doctor: Doctor) => void;
}

export function AppointmentsPage({ onBookDoctor }: AppointmentsPageProps) {
  const { doctors, departments, language } = useData();
  const [selectedDept, setSelectedDept] = useState('all');
  const isBn = language === 'bn';

  const activeDoctors = doctors.filter(
    (d) => d.active && (selectedDept === 'all' || d.department === selectedDept)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-1">
          {isBn ? 'ডাবল-বুকিং সুরক্ষিত সিস্টেম' : 'Double-Booking Protected Scheduling'}
        </p>
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'অনলাইন ডাক্তার অ্যাপয়েন্টমেন্ট বুকিং' : 'Online Doctor Appointment Booking'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          {isBn
            ? 'বিশেষজ্ঞ ডাক্তার নির্বাচন করে তারিখ ও উন্মুক্ত সময় স্লট অনুযায়ী তাৎক্ষণিক অ্যাপয়েন্টমেন্ট নিশ্চিত করুন।'
            : 'Choose a doctor below to check live slot availability and submit your appointment request.'}
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setSelectedDept('all')}
          className={`px-3.5 py-2 text-xs font-medium rounded-lg border cursor-pointer ${
            selectedDept === 'all'
              ? 'bg-blue-700 text-white border-blue-700'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
          }`}
        >
          {isBn ? 'সকল বিভাগ' : 'All Departments'}
        </button>
        {departments.map((dept) => (
          <button
            key={dept.id}
            type="button"
            onClick={() => setSelectedDept(dept.nameBn)}
            className={`px-3.5 py-2 text-xs font-medium rounded-lg border cursor-pointer ${
              selectedDept === dept.nameBn
                ? 'bg-blue-700 text-white border-blue-700'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {isBn ? dept.nameBn : dept.nameEn}
          </button>
        ))}
      </div>

      {activeDoctors.length === 0 ? (
        <div className="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-500">
          {isBn ? 'এই বিভাগে কোনো ডাক্তার পাওয়া যায়নি।' : 'No doctors available in this department.'}
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {activeDoctors.map((doc) => (
            <div
              key={doc.id}
              className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col justify-between gap-4"
            >
              <div>
                <p className="text-xs text-blue-700 dark:text-blue-400 font-medium">
                  {doc.department} · {doc.location}
                </p>
                <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                  {doc.name}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">{doc.degree}</p>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2">
                  {doc.hospitalName}
                </p>
                {doc.visitingSchedule && (
                  <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-blue-700" />
                    <span>{doc.visitingSchedule}</span>
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                <span className="font-display font-bold text-blue-800 dark:text-blue-400 tabular-nums">
                  ৳ {doc.consultationFee}
                </span>
                <button
                  type="button"
                  onClick={() => onBookDoctor(doc)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  <span>{isBn ? 'সময় নির্বাচন করুন' : 'Select Slot'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
