import { useState, FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search,
  Star,
  Heart,
  PhoneCall,
  ArrowRight,
  Stethoscope,
  Building2,
  FlaskConical,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { t } from '../lib/i18n';
import { toggleFavoriteItem } from '../services/firestoreService';
import { Doctor } from '../types/healthcare';
import { AdBannerSlot } from '../components/AdBannerSlot';
import { ResilientImage } from '../components/ResilientImage';

interface HomePageProps {
  onBookDoctor: (doctor: Doctor) => void;
  onOpenAuth: () => void;
}

export function HomePage({ onBookDoctor, onOpenAuth }: HomePageProps) {
  const { firebaseUser, userProfile } = useAuth();
  const {
    language,
    doctors,
    hospitals,
    diagnosticCenters,
    departments,
    healthTips,
    appSettings,
    dataLoading,
  } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const copy = t(language);
  const isBn = language === 'bn';

  const activeDoctors = doctors.filter((d) => d.active);
  const featuredDoctors = activeDoctors.filter((d) => d.featured).slice(0, 6);
  const displayDoctors = featuredDoctors.length > 0 ? featuredDoctors : activeDoctors.slice(0, 6);

  const publishedHospitals = hospitals.filter((h) => h.published);
  const displayHospitals = publishedHospitals.slice(0, 4);

  const publishedDiagnostics = diagnosticCenters.filter((c) => c.published);
  const publishedTips = healthTips.filter((tip) => tip.published).slice(0, 3);

  function handleSearchSubmit(e: FormEvent) {
    e.preventDefault();
    const q = searchQuery.trim();
    navigate(q ? `/doctors?q=${encodeURIComponent(q)}` : '/doctors');
  }

  async function handleFavoriteDoctor(docId: string) {
    if (!firebaseUser) {
      onOpenAuth();
      return;
    }
    const isFav = userProfile?.favoriteDoctorIds?.includes(docId) ?? false;
    await toggleFavoriteItem(firebaseUser.uid, 'doctor', docId, isFav);
  }

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="pt-8 sm:pt-12 lg:pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center">
              <p className="text-sm font-medium text-blue-700 dark:text-blue-400 mb-2">
                {copy.hero.kicker}
              </p>
              <h1 className="font-display text-[clamp(2.1rem,3.8vw,3.35rem)] font-bold tracking-tight text-slate-900 dark:text-white leading-[1.16] mb-4 [text-wrap:balance]">
                {copy.hero.title}
              </h1>
              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed mb-7 max-w-2xl">
                {copy.hero.subtitle}
              </p>

              {/* Unified Healthcare Search Bar */}
              <form
                onSubmit={handleSearchSubmit}
                className="flex flex-col sm:flex-row gap-2.5 p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs mb-6"
              >
                <div className="relative flex-1 flex items-center">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={copy.actions.searchPlaceholder}
                    aria-label={copy.actions.searchPlaceholder}
                    className="w-full min-h-[44px] pl-9 pr-3 py-2 text-sm bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {copy.actions.searchBtn}
                </button>
              </form>

              <div className="flex flex-wrap items-center gap-4">
                <Link
                  to="/doctors"
                  className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>{copy.hero.ctaPrimary}</span>
                </Link>
                <Link
                  to="/hospitals"
                  className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-blue-800 dark:text-blue-300 bg-blue-50 dark:bg-slate-900 border border-blue-200 dark:border-slate-700 hover:bg-blue-100 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap"
                >
                  <Building2 className="w-4 h-4" />
                  <span>{copy.hero.ctaSecondary}</span>
                </Link>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="h-full min-h-[260px] lg:min-h-[380px] rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <ResilientImage
                  src="/src/assets/images/hero_healthcare_bangladesh_1794682597661.jpg"
                  alt="Dial for Health আধুনিক হাসপাতাল ও ডিজিটাল স্বাস্থ্যসেবা কেন্দ্র"
                  fallbackTitle="Dial for Health Bangladesh"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* 4-Column Live Firestore Directory Metrics Strip */}
          <div className="mt-10 pt-8 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
                {activeDoctors.length}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {isBn ? 'তালিকাভুক্ত বিশেষজ্ঞ ডাক্তার' : 'Active Specialist Doctors'}
              </p>
            </div>
            <div>
              <p className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
                {publishedHospitals.length}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {isBn ? 'অনুমোদিত হাসপাতাল' : 'Verified Hospitals'}
              </p>
            </div>
            <div>
              <p className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
                {publishedDiagnostics.length}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {isBn ? 'ডায়াগনস্টিক সেন্টার' : 'Diagnostic Centers'}
              </p>
            </div>
            <div>
              <p className="font-display text-2xl sm:text-3xl font-bold text-blue-700 dark:text-blue-400 tabular-nums">
                {appSettings.emergencyHotline}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {isBn ? '২৪/৭ জাতীয় জরুরি হটলাইন' : '24/7 Emergency Hotline'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Top Dynamic Advertisement Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdBannerSlot placement="home_top" />
      </section>

      {/* Medical Departments */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between gap-4 mb-6">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
              {isBn ? 'চিকিৎসা বিভাগসমূহ' : 'Medical Departments'}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              {isBn
                ? 'আপনার প্রয়োজনীয় বিশেষজ্ঞ বিভাগ বেছে নিয়ে ডাক্তার খুঁজুন'
                : 'Select a clinical specialty to browse verified doctors'}
            </p>
          </div>
          <Link
            to="/doctors"
            className="text-sm font-semibold text-blue-700 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0"
          >
            {isBn ? 'সকল বিভাগ দেখুন' : 'View All'}
          </Link>
        </div>

        {departments.filter((d) => d.active).length === 0 ? (
          <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-600 dark:text-slate-400">
            {dataLoading
              ? isBn
                ? 'বিভাগগুলো লোড হচ্ছে...'
                : 'Loading departments...'
              : isBn
              ? 'Firestore-এ এখনো কোনো বিভাগ যুক্ত করা হয়নি। অ্যাডমিন ড্যাশবোর্ড থেকে বিভাগ যুক্ত করুন।'
              : 'No departments found in Firestore yet. Add departments from Admin Dashboard.'}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {departments
              .filter((d) => d.active)
              .map((dept) => (
                <Link
                  key={dept.id}
                  to={`/doctors?department=${encodeURIComponent(dept.nameBn)}`}
                  className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-600 rounded-xl transition-colors flex flex-col justify-between"
                >
                  <div>
                    <p className="font-display font-semibold text-sm text-slate-900 dark:text-white">
                      {isBn ? dept.nameBn : dept.nameEn}
                    </p>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      {dept.description || dept.nameEn}
                    </p>
                  </div>
                  <span className="text-xs font-medium text-blue-700 dark:text-blue-400 mt-3 inline-flex items-center gap-1">
                    {isBn ? 'ডাক্তার দেখুন' : 'Browse'}
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </Link>
              ))}
          </div>
        )}
      </section>

      {/* Featured Doctors Directory Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between gap-4 mb-6">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
              {isBn ? 'বিশেষজ্ঞ ডাক্তারবৃন্দ' : 'Featured Specialist Doctors'}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              {isBn
                ? 'Firebase ডেটাবেস থেকে সরাসরি সংযুক্ত সক্রিয় চিকিৎসক তালিকা'
                : 'Live specialist directory synchronized from Cloud Firestore'}
            </p>
          </div>
          <Link
            to="/doctors"
            className="text-sm font-semibold text-blue-700 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0"
          >
            {isBn ? 'সকল ডাক্তার' : 'All Doctors'}
          </Link>
        </div>

        {displayDoctors.length === 0 ? (
          <div className="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center space-y-3">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {dataLoading
                ? isBn
                  ? 'ডাক্তারদের তালিকা লোড হচ্ছে...'
                  : 'Loading doctors from Firestore...'
                : isBn
                ? 'Firestore-এ এখনো কোনো ডাক্তার যুক্ত করা হয়নি।'
                : 'No doctors added in Firestore yet.'}
            </p>
            <Link
              to="/admin/login"
              className="inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg"
            >
              {isBn ? 'অ্যাডমিন প্যানেল থেকে ডাক্তার যুক্ত করুন' : 'Add Doctors in Admin Panel'}
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayDoctors.map((doc) => {
              const isFav = userProfile?.favoriteDoctorIds?.includes(doc.id) ?? false;
              return (
                <article
                  key={doc.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start gap-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0 bg-slate-100 dark:bg-slate-800">
                        <ResilientImage
                          src={doc.photoUrl}
                          alt={doc.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {doc.department} · {doc.location}
                          </p>
                          <button
                            type="button"
                            onClick={() => void handleFavoriteDoctor(doc.id)}
                            aria-label="Toggle Favorite Doctor"
                            className="p-1 text-slate-400 hover:text-red-600 cursor-pointer shrink-0"
                          >
                            <Heart
                              className={`w-4 h-4 ${
                                isFav ? 'fill-red-600 text-red-600' : ''
                              }`}
                            />
                          </button>
                        </div>
                        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white leading-snug mt-0.5">
                          {doc.name}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 line-clamp-1">
                          {doc.degree}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1 text-xs text-slate-600 dark:text-slate-300">
                      <p className="font-medium text-slate-800 dark:text-slate-200">
                        {doc.hospitalName}
                      </p>
                      {doc.visitingSchedule && <p>{doc.visitingSchedule}</p>}
                      <div className="flex items-center justify-between pt-1">
                        <span className="inline-flex items-center gap-1 tabular-nums">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                          {(doc.rating || 5.0).toFixed(1)} ({doc.reviewCount || 0})
                        </span>
                        <span className="font-semibold text-blue-800 dark:text-blue-400 tabular-nums">
                          {isBn ? 'ফি:' : 'Fee:'} ৳ {doc.consultationFee}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onBookDoctor(doc)}
                      className="flex-1 min-h-[40px] px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
                    >
                      {copy.actions.bookNow}
                    </button>
                    <Link
                      to={`/doctors?id=${doc.id}`}
                      className="px-3.5 py-2 min-h-[40px] inline-flex items-center text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-slate-300 rounded-lg"
                    >
                      {copy.actions.viewDetails}
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Middle Dynamic Advertisement Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdBannerSlot placement="home_middle" />
      </section>

      {/* Featured Hospitals & Diagnostic Centers */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-5">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                {isBn ? 'নিবন্ধিত হাসপাতালসমূহ' : 'Verified Hospitals'}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                {isBn ? 'জরুরি বিভাগ ও বিশেষায়িত চিকিৎসা কেন্দ্র' : 'Emergency & multi-specialty centers'}
              </p>
            </div>
            <Link to="/hospitals" className="text-sm font-semibold text-blue-700 dark:text-blue-400 hover:underline">
              {isBn ? 'সব দেখুন' : 'View All'}
            </Link>
          </div>

          {displayHospitals.length === 0 ? (
            <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-500">
              {isBn ? 'এখনো কোনো হাসপাতাল প্রকাশিত হয়নি।' : 'No hospitals published yet.'}
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-5">
              {displayHospitals.map((h) => (
                <article
                  key={h.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    <div className="aspect-[16/10] bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-800">
                      <ResilientImage
                        src={h.imageUrl}
                        alt={h.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-4">
                      <p className="text-xs text-slate-500 mb-1">
                        {h.location} · {h.emergencyPhone ? `জরুরি: ${h.emergencyPhone}` : h.contactPhone}
                      </p>
                      <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
                        {h.name}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                        {h.address}
                      </p>
                    </div>
                  </div>
                  <div className="px-4 pb-4">
                    <Link
                      to={`/hospitals?id=${h.id}`}
                      className="text-xs font-semibold text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                    >
                      <span>{copy.actions.viewDetails}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>

        {/* Emergency & Diagnostic Quick Panel */}
        <div className="lg:col-span-5 space-y-5">
          <div className="p-6 bg-blue-900 text-white rounded-xl space-y-3">
            <div className="flex items-center gap-2 text-blue-200 text-xs font-medium">
              <ShieldAlert className="w-4 h-4" />
              <span>{isBn ? '২৪ ঘণ্টা জরুরি চিকিৎসা সহায়তা' : '24/7 Emergency Medical Support'}</span>
            </div>
            <h3 className="font-display text-2xl font-bold">
              {isBn ? 'জরুরি অ্যাম্বুলেন্স ও হেল্পলাইন' : 'Emergency Ambulance & Hotline'}
            </h3>
            <p className="text-sm text-blue-100 leading-relaxed">
              {isBn
                ? 'যেকোনো জরুরি মেডিকেল পরিস্থিতিতে সরাসরি জাতীয় জরুরি সেবা বা আমাদের হেল্পলাইনে কল করুন।'
                : 'In critical medical situations, call the national emergency line or our support desk directly.'}
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <a
                href={`tel:${appSettings.supportPhone}`}
                className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] bg-white text-blue-900 font-semibold text-sm rounded-lg tabular-nums"
              >
                <PhoneCall className="w-4 h-4" />
                <span>{appSettings.emergencyHotline}</span>
              </a>
              <Link
                to="/diagnostic-centers"
                className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] bg-blue-800 hover:bg-blue-700 text-white font-medium text-sm rounded-lg border border-blue-700"
              >
                <FlaskConical className="w-4 h-4" />
                <span>{isBn ? 'ডায়াগনস্টিক টেস্ট মূল্য' : 'Diagnostic Tests'}</span>
              </Link>
            </div>
          </div>

          {/* Health Tips Card */}
          <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-4">
              {isBn ? 'স্বাস্থ্য পরামর্শ (Health Tips)' : 'Health Tips'}
            </h3>
            {publishedTips.length === 0 ? (
              <p className="text-xs text-slate-500">
                {isBn ? 'কোনো স্বাস্থ্য পরামর্শ এখনো যুক্ত হয়নি।' : 'No health tips published yet.'}
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {publishedTips.map((tip) => (
                  <article key={tip.id} className="py-3 first:pt-0 last:pb-0">
                    <p className="text-xs text-blue-700 dark:text-blue-400 font-medium">
                      {tip.category} {tip.author ? `· ${tip.author}` : ''}
                    </p>
                    <h4 className="font-display font-semibold text-sm text-slate-900 dark:text-white mt-0.5">
                      {tip.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      {tip.summary}
                    </p>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Bottom Dynamic Advertisement Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdBannerSlot placement="home_bottom" />
      </section>
    </div>
  );
}
