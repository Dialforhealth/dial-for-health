import { useState } from 'react';
import { Search, MapPin, Clock, PhoneCall, ExternalLink } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { AdBannerSlot } from '../components/AdBannerSlot';
import { ResilientImage } from '../components/ResilientImage';

export function DiagnosticsPage() {
  const { diagnosticCenters, language } = useData();
  const [queryText, setQueryText] = useState('');
  const isBn = language === 'bn';

  const published = diagnosticCenters.filter((c) => c.published);
  const filtered = published.filter((c) => {
    const q = queryText.trim().toLowerCase();
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) ||
      c.location.toLowerCase().includes(q) ||
      (c.availableTests || []).some((t) => t.name.toLowerCase().includes(q))
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'ডায়াগনস্টিক সেন্টার ও টেস্টের মূল্য' : 'Diagnostic Centers & Test Pricing'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          {isBn
            ? 'প্যাথলজি, রক্ত পরীক্ষা, এক্স-রে ও ইমেজিং টেস্টের নির্ধারিত মূল্য ও সময়সূচি দেখুন'
            : 'Explore diagnostic centers, available pathology tests, and transparent BDT pricing'}
        </p>
      </div>

      <AdBannerSlot placement="diagnostic_banner" />

      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
        <div className="relative max-w-xl">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder={
              isBn
                ? 'সেন্টারের নাম, এলাকা বা টেস্টের নাম (যেমন: CBC, X-Ray)...'
                : 'Search center name, city, or test name...'
            }
            className="w-full min-h-[42px] pl-9 pr-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="p-10 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center text-sm text-slate-500">
          {isBn ? 'কোনো ডায়াগনস্টিক সেন্টার পাওয়া যায়নি।' : 'No diagnostic centers found.'}
        </div>
      ) : (
        <div className="space-y-6">
          {filtered.map((center) => (
            <article
              key={center.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden grid lg:grid-cols-12"
            >
              <div className="lg:col-span-4 min-h-[220px] bg-slate-100 dark:bg-slate-800 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800">
                <ResilientImage
                  src={center.imageUrl}
                  alt={center.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="lg:col-span-8 p-6 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium text-blue-700 dark:text-blue-400">
                      {center.location}
                    </p>
                    <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                      {center.name}
                    </h2>
                    <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-blue-700" />
                      <span>{center.address}</span>
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <a
                      href={`tel:${center.contactPhone}`}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg tabular-nums"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>{center.contactPhone}</span>
                    </a>
                    {center.websiteUrl && (
                      <a
                        href={center.websiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-3 py-2 text-xs font-medium border border-slate-300 dark:border-slate-700 rounded-lg"
                      >
                        <span>Website</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>

                {center.serviceDetails && (
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {center.serviceDetails}
                  </p>
                )}

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
                  {center.openingHours && (
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-blue-700" />
                      {center.openingHours}
                    </span>
                  )}
                  {center.appointmentInfo && <span>· {center.appointmentInfo}</span>}
                </div>

                {center.availableTests && center.availableTests.length > 0 && (
                  <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 dark:bg-slate-800 text-xs text-slate-500">
                        <tr>
                          <th className="text-left px-4 py-2.5 font-medium">
                            {isBn ? 'উপলব্ধ টেস্ট' : 'Available Test'}
                          </th>
                          <th className="text-right px-4 py-2.5 font-medium">
                            {isBn ? 'মূল্য (BDT)' : 'Price (BDT)'}
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                        {center.availableTests.map((test, idx) => (
                          <tr key={`${test.name}-${idx}`}>
                            <td className="px-4 py-2.5 text-slate-800 dark:text-slate-200">
                              {test.name}
                            </td>
                            <td className="px-4 py-2.5 text-right font-semibold text-blue-800 dark:text-blue-400 tabular-nums">
                              ৳ {Number(test.price).toLocaleString('en-US')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
