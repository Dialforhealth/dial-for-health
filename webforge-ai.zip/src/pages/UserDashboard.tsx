import { useEffect, useState, FormEvent, ChangeEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  Heart,
  User as UserIcon,
  Bell,
  LogOut,
  CheckCircle2,
  AlertCircle,
  Upload,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { t } from '../lib/i18n';
import {
  cancelUserAppointment,
  markNotificationRead,
  subscribeUserAppointments,
  toggleFavoriteItem,
  updateUserProfileData,
  uploadHealthcareImage,
} from '../services/firestoreService';
import { Appointment, Doctor } from '../types/healthcare';
import { ResilientImage } from '../components/ResilientImage';

interface UserDashboardProps {
  onOpenAuth: () => void;
  onBookDoctor: (doctor: Doctor) => void;
}

type DashTab = 'appointments' | 'favorites' | 'profile' | 'notifications';

export function UserDashboard({ onOpenAuth, onBookDoctor }: UserDashboardProps) {
  const {
    firebaseUser,
    authReady,
    role,
    userProfile,
    userPrivate,
    changePassword,
    logout,
  } = useAuth();
  const { language, doctors, hospitals, notifications } = useData();
  const isBn = language === 'bn';
  const copy = t(language);

  const [activeTab, setActiveTab] = useState<DashTab>('appointments');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [gender, setGender] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    if (!firebaseUser) {
      setAppointments([]);
      return;
    }
    const unsub = subscribeUserAppointments(firebaseUser.uid, setAppointments);
    return () => unsub();
  }, [firebaseUser]);

  useEffect(() => {
    if (userProfile) setDisplayName(userProfile.displayName || '');
    if (userPrivate) {
      setPhone(userPrivate.phone || '');
      setAddress(userPrivate.address || '');
      setBloodGroup(userPrivate.bloodGroup || '');
      setGender(userPrivate.gender || '');
    }
  }, [userProfile, userPrivate]);

  if (!authReady) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-16 text-center text-sm text-slate-500">
        {isBn ? 'লোড হচ্ছে...' : 'Loading session...'}
      </div>
    );
  }

  if (!firebaseUser) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center space-y-4">
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'ইউজার ড্যাশবোর্ড (/dashboard)' : 'User Dashboard'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          {isBn
            ? 'আপনার অ্যাপয়েন্টমেন্ট, পছন্দের ডাক্তার ও প্রোফাইল দেখতে অনুগ্রহ করে লগইন করুন।'
            : 'Please sign in to access your appointments, saved favorites, and profile.'}
        </p>
        <button
          type="button"
          onClick={onOpenAuth}
          className="px-6 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
        >
          {copy.actions.login}
        </button>
      </div>
    );
  }

  const filteredAppointments = appointments.filter(
    (a) => statusFilter === 'all' || a.status === statusFilter
  );

  const favDoctors = doctors.filter((d) =>
    userProfile?.favoriteDoctorIds?.includes(d.id)
  );
  const favHospitals = hospitals.filter((h) =>
    userProfile?.favoriteHospitalIds?.includes(h.id)
  );

  async function handlePhotoUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !firebaseUser) return;
    setBusy(true);
    setFeedback(null);
    try {
      const url = await uploadHealthcareImage(file, 'profiles', firebaseUser.uid);
      await updateUserProfileData(firebaseUser.uid, { photoUrl: url }, {});
      setFeedback({
        type: 'ok',
        text: isBn ? 'প্রোফাইল ছবি আপডেট হয়েছে।' : 'Profile photo updated.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }

  async function handleProfileSave(e: FormEvent) {
    e.preventDefault();
    if (!firebaseUser) return;
    setBusy(true);
    setFeedback(null);
    try {
      await updateUserProfileData(
        firebaseUser.uid,
        { displayName: displayName.trim() },
        { phone: phone.trim(), address: address.trim(), bloodGroup, gender }
      );
      setFeedback({
        type: 'ok',
        text: isBn ? 'প্রোফাইল তথ্য সংরক্ষিত হয়েছে।' : 'Profile details saved.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }

  async function handlePasswordChange(e: FormEvent) {
    e.preventDefault();
    if (newPassword.length < 6) {
      setFeedback({
        type: 'err',
        text: isBn ? 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Minimum 6 characters required.',
      });
      return;
    }
    setBusy(true);
    setFeedback(null);
    try {
      await changePassword(newPassword);
      setNewPassword('');
      setFeedback({
        type: 'ok',
        text: isBn ? 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে।' : 'Password updated successfully.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Card */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full overflow-hidden border border-slate-200 dark:border-slate-700 bg-blue-50 dark:bg-slate-800 shrink-0">
            <ResilientImage
              src={userProfile?.photoUrl || firebaseUser.photoURL || ''}
              alt={userProfile?.displayName || 'User'}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <p className="text-xs text-blue-700 dark:text-blue-400 font-mono-tabular">
              {userProfile?.userCode || 'DFH-USER'} · {firebaseUser.email || firebaseUser.phoneNumber}
            </p>
            <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              {userProfile?.displayName || firebaseUser.displayName || 'রোগী'}
            </h1>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {role === 'admin' && (
            <Link
              to="/admin/dashboard"
              className="px-4 py-2 min-h-[40px] inline-flex items-center text-xs font-semibold text-white bg-blue-700 rounded-lg"
            >
              {isBn ? 'অ্যাডমিন ড্যাশবোর্ডে যান' : 'Go to Admin Dashboard'}
            </Link>
          )}
          <button
            type="button"
            onClick={() => void logout()}
            className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>{copy.actions.logout}</span>
          </button>
        </div>
      </div>

      {/* Dashboard Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        {[
          { id: 'appointments', label: isBn ? 'অ্যাপয়েন্টমেন্টসমূহ' : 'Appointments', icon: Calendar },
          { id: 'favorites', label: isBn ? 'পছন্দের তালিকা' : 'Favorites', icon: Heart },
          { id: 'notifications', label: isBn ? 'নোটিফিকেশন' : 'Notifications', icon: Bell },
          { id: 'profile', label: isBn ? 'প্রোফাইল ও নিরাপত্তা' : 'Profile & Security', icon: UserIcon },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as DashTab)}
              className={`inline-flex items-center gap-2 px-4 py-2 min-h-[40px] text-sm font-medium rounded-lg cursor-pointer transition-colors ${
                active
                  ? 'bg-blue-700 text-white'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-lg border flex items-center gap-2 text-sm ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-900 text-red-800 dark:text-red-300'
          }`}
        >
          {feedback.type === 'ok' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Appointments Tab */}
      {activeTab === 'appointments' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              {(['all', 'pending', 'confirmed', 'completed', 'cancelled'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border cursor-pointer ${
                    statusFilter === st
                      ? 'bg-slate-900 dark:bg-blue-700 text-white border-transparent'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {st === 'all' ? (isBn ? 'সবগুলো' : 'All') : copy.status[st]}
                </button>
              ))}
            </div>
            <Link
              to="/appointments"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
            >
              {isBn ? 'নতুন অ্যাপয়েন্টমেন্ট নিন' : 'Book New Appointment'}
            </Link>
          </div>

          {filteredAppointments.length === 0 ? (
            <div className="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center text-sm text-slate-500">
              {isBn ? 'কোনো অ্যাপয়েন্টমেন্ট পাওয়া যায়নি।' : 'No appointments found.'}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {filteredAppointments.map((app) => (
                <div
                  key={app.id}
                  className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-mono-tabular text-xs font-medium text-blue-700 dark:text-blue-400">
                        {app.appointmentCode} · {copy.status[app.status]}
                      </p>
                      <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                        {app.doctorName}
                      </h3>
                      <p className="text-xs text-slate-500">{app.hospitalName}</p>
                    </div>
                    <span className="font-semibold text-sm tabular-nums text-slate-900 dark:text-white">
                      ৳ {app.consultationFee}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <p className="tabular-nums">
                      {isBn ? 'তারিখ ও সময়:' : 'Schedule:'} {app.appointmentDate} · {app.appointmentTime}
                    </p>
                    <p>
                      {isBn ? 'রোগী:' : 'Patient:'} {app.patientName} ({app.patientAge} yrs · {app.patientPhone})
                    </p>
                  </div>

                  {(app.status === 'pending' || app.status === 'confirmed') && (
                    <button
                      type="button"
                      onClick={() => void cancelUserAppointment(app)}
                      className="px-3.5 py-1.5 text-xs font-medium text-red-700 dark:text-red-400 border border-red-200 dark:border-red-900 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg cursor-pointer"
                    >
                      {isBn ? 'অ্যাপয়েন্টমেন্ট বাতিল করুন' : 'Cancel Appointment'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Favorites Tab */}
      {activeTab === 'favorites' && (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
            <h2 className="font-display font-bold text-lg">
              {isBn ? 'পছন্দের ডাক্তারবৃন্দ' : 'Favorite Doctors'}
            </h2>
            {favDoctors.length === 0 ? (
              <p className="text-xs text-slate-500">
                {isBn ? 'কোনো ডাক্তার পছন্দের তালিকায় যুক্ত করা হয়নি।' : 'No favorite doctors saved yet.'}
              </p>
            ) : (
              favDoctors.map((d) => (
                <div key={d.id} className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 dark:border-slate-800 last:border-0">
                  <div>
                    <p className="font-semibold text-sm">{d.name}</p>
                    <p className="text-xs text-slate-500">{d.department} · {d.hospitalName}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onBookDoctor(d)}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer"
                    >
                      {isBn ? 'বুক করুন' : 'Book'}
                    </button>
                    <button
                      type="button"
                      onClick={() => void toggleFavoriteItem(firebaseUser.uid, 'doctor', d.id, true)}
                      className="text-xs text-red-600 cursor-pointer"
                    >
                      {isBn ? 'সরান' : 'Remove'}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
            <h2 className="font-display font-bold text-lg">
              {isBn ? 'পছন্দের হাসপাতালসমূহ' : 'Favorite Hospitals'}
            </h2>
            {favHospitals.length === 0 ? (
              <p className="text-xs text-slate-500">
                {isBn ? 'কোনো হাসপাতাল পছন্দের তালিকায় যুক্ত করা হয়নি।' : 'No favorite hospitals saved yet.'}
              </p>
            ) : (
              favHospitals.map((h) => (
                <div key={h.id} className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 dark:border-slate-800 last:border-0">
                  <div>
                    <p className="font-semibold text-sm">{h.name}</p>
                    <p className="text-xs text-slate-500">{h.location} · {h.contactPhone}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void toggleFavoriteItem(firebaseUser.uid, 'hospital', h.id, true)}
                    className="text-xs text-red-600 cursor-pointer"
                  >
                    {isBn ? 'সরান' : 'Remove'}
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Notifications Tab */}
      {activeTab === 'notifications' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
          {notifications.length === 0 ? (
            <p className="p-8 text-center text-sm text-slate-500">
              {isBn ? 'কোনো নোটিফিকেশন নেই।' : 'No notifications yet.'}
            </p>
          ) : (
            notifications.map((n) => {
              const isRead = n.readBy?.includes(firebaseUser.uid);
              return (
                <div key={n.id} className="p-4 flex items-start justify-between gap-4">
                  <div>
                    <p className={`text-sm font-semibold ${isRead ? 'text-slate-600 dark:text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                      {n.title}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{n.message}</p>
                  </div>
                  {!isRead && (
                    <button
                      type="button"
                      onClick={() => void markNotificationRead(n.id, firebaseUser.uid)}
                      className="px-3 py-1 text-xs font-medium text-blue-700 border border-blue-200 rounded-lg cursor-pointer shrink-0"
                    >
                      {isBn ? 'পঠিত' : 'Mark Read'}
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Profile & Security Tab */}
      {activeTab === 'profile' && (
        <div className="grid md:grid-cols-2 gap-6">
          <form
            onSubmit={handleProfileSave}
            className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
          >
            <h2 className="font-display font-bold text-lg">
              {isBn ? 'ব্যক্তিগত তথ্য ও ছবি' : 'Personal Information & Photo'}
            </h2>

            <div>
              <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                <Upload className="w-4 h-4 text-blue-700" />
                <span>{isBn ? 'প্রোফাইল ছবি আপলোড করুন' : 'Upload Profile Photo'}</span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
              </label>
            </div>

            <div>
              <label className="block text-xs font-medium mb-1">
                {isBn ? 'পূর্ণ নাম' : 'Full Name'}
              </label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1">
                  {isBn ? 'মোবাইল নম্বর' : 'Mobile Number'}
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">
                  {isBn ? 'রক্তের গ্রুপ' : 'Blood Group'}
                </label>
                <select
                  value={bloodGroup}
                  onChange={(e) => setBloodGroup(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
                >
                  <option value="">—</option>
                  {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium mb-1">
                {isBn ? 'ঠিকানা' : 'Address'}
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
              />
            </div>

            <button
              type="submit"
              disabled={busy}
              className="px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
            >
              {copy.actions.save}
            </button>
          </form>

          <form
            onSubmit={handlePasswordChange}
            className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 h-fit"
          >
            <h2 className="font-display font-bold text-lg">
              {isBn ? 'পাসওয়ার্ড পরিবর্তন' : 'Change Password'}
            </h2>
            <p className="text-xs text-slate-500">
              {isBn
                ? 'নিরাপত্তার জন্য শক্তিশালী কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড ব্যবহার করুন।'
                : 'Use a strong password of at least 6 characters.'}
            </p>
            <div>
              <label className="block text-xs font-medium mb-1">
                {isBn ? 'নতুন পাসওয়ার্ড' : 'New Password'}
              </label>
              <input
                type="password"
                minLength={6}
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 rounded-lg cursor-pointer"
            >
              {isBn ? 'পাসওয়ার্ড আপডেট করুন' : 'Update Password'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
