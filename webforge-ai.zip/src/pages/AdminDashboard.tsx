import { useEffect, useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  Bell,
  Building2,
  Calendar,
  Database,
  FileText,
  FlaskConical,
  LayoutDashboard,
  Lock,
  LogOut,
  Megaphone,
  Settings,
  Shield,
  Stethoscope,
  Users,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import {
  adminUpdateAppointment,
  deleteEntity,
  saveAppSettings,
  saveEntity,
  seedInitialHealthcareData,
  sendAdminNotification,
  subscribeCollection,
} from '../services/firestoreService';
import {
  ActivityLog,
  AdminAccount,
  Appointment,
  AppointmentStatus,
  UserPublicProfile,
} from '../types/healthcare';
import {
  AdminAdsPanel,
  AdminDiagnosticsPanel,
  AdminDoctorsPanel,
  AdminHospitalsPanel,
} from '../components/admin/AdminCatalogPanels';

type AdminSection =
  | 'overview'
  | 'users'
  | 'doctors'
  | 'hospitals'
  | 'diagnostics'
  | 'appointments'
  | 'advertisements'
  | 'departments'
  | 'notifications'
  | 'health_tips'
  | 'settings'
  | 'admins'
  | 'logs';

export function AdminDashboard() {
  const { firebaseUser, authReady, role, logout } = useAuth();
  const {
    doctors,
    hospitals,
    diagnosticCenters,
    departments,
    advertisements,
    healthTips,
    appSettings,
  } = useData();

  const [section, setSection] = useState<AdminSection>('overview');
  const [users, setUsers] = useState<UserPublicProfile[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [admins, setAdmins] = useState<AdminAccount[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);

  // Department form
  const [deptNameBn, setDeptNameBn] = useState('');
  const [deptNameEn, setDeptNameEn] = useState('');
  const [deptDesc, setDeptDesc] = useState('');

  // Notification form
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMsg, setNotifMsg] = useState('');
  const [notifTarget, setNotifTarget] = useState('all');

  // Health tip form
  const [tipTitle, setTipTitle] = useState('');
  const [tipCat, setTipCat] = useState('সাধারণ স্বাস্থ্য');
  const [tipSummary, setTipSummary] = useState('');
  const [tipAuthor, setTipAuthor] = useState('');

  // Settings form
  const [settingsForm, setSettingsForm] = useState(appSettings);

  // Admin account form
  const [newAdminUid, setNewAdminUid] = useState('');
  const [newAdminId, setNewAdminId] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminLevel, setNewAdminLevel] = useState<'super_admin' | 'manager' | 'moderator'>('manager');

  useEffect(() => {
    setSettingsForm(appSettings);
  }, [appSettings]);

  useEffect(() => {
    if (role !== 'admin') return;
    const u1 = subscribeCollection<UserPublicProfile>('users', setUsers);
    const u2 = subscribeCollection<Appointment>('appointments', setAppointments, 'createdAt');
    const u3 = subscribeCollection<AdminAccount>('admins', setAdmins);
    const u4 = subscribeCollection<ActivityLog>('activity_logs', setLogs, 'createdAt');
    return () => {
      u1();
      u2();
      u3();
      u4();
    };
  }, [role]);

  function notify(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  }

  if (!authReady) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-16 text-center text-sm text-slate-500">
        অ্যাডমিন সেশন যাচাই হচ্ছে...
      </div>
    );
  }

  if (!firebaseUser || role !== 'admin') {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <Lock className="w-10 h-10 text-red-600 mx-auto" />
        <h1 className="font-display text-2xl font-bold">সুরক্ষিত অ্যাডমিন এলাকা</h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          এই ড্যাশবোর্ডে প্রবেশের জন্য অনুমোদিত অ্যাডমিন অ্যাকাউন্ট প্রয়োজন।
        </p>
        <Link
          to="/admin/login"
          className="inline-flex px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 rounded-lg"
        >
          অ্যাডমিন লগইনে যান
        </Link>
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];
  const activeAdsCount = advertisements.filter(
    (ad) => ad.active && (!ad.expiryDate || ad.expiryDate >= today)
  ).length;
  const pendingCount = appointments.filter((a) => a.status === 'pending').length;
  const confirmedCount = appointments.filter((a) => a.status === 'confirmed').length;

  async function handleSeedData() {
    setSeeding(true);
    try {
      await seedInitialHealthcareData();
      notify('Firestore-এ প্রাথমিক বাংলাদেশি হেলথকেয়ার ডেটা সফলভাবে যুক্ত হয়েছে।');
    } catch (err) {
      notify(err instanceof Error ? err.message : String(err));
    } finally {
      setSeeding(false);
    }
  }

  const navItems: Array<{ id: AdminSection; label: string; icon: typeof LayoutDashboard }> = [
    { id: 'overview', label: 'ড্যাশবোর্ড ওভারভিউ', icon: LayoutDashboard },
    { id: 'users', label: 'A. ইউজার ম্যানেজমেন্ট', icon: Users },
    { id: 'doctors', label: 'B. ডাক্তার ম্যানেজমেন্ট', icon: Stethoscope },
    { id: 'hospitals', label: 'C. হাসপাতাল ম্যানেজমেন্ট', icon: Building2 },
    { id: 'diagnostics', label: 'D. ডায়াগনস্টিক সেন্টার', icon: FlaskConical },
    { id: 'appointments', label: 'E. অ্যাপয়েন্টমেন্টসমূহ', icon: Calendar },
    { id: 'advertisements', label: 'F/G. বিজ্ঞাপন ও ব্যানার', icon: Megaphone },
    { id: 'departments', label: 'H. মেডিকেল বিভাগ', icon: FileText },
    { id: 'notifications', label: 'I. নোটিফিকেশন প্রেরণ', icon: Bell },
    { id: 'health_tips', label: 'J. স্বাস্থ্য পরামর্শ', icon: FileText },
    { id: 'settings', label: 'K/L. কনটেন্ট ও সেটিংস', icon: Settings },
    { id: 'admins', label: 'M. অ্যাডমিন অ্যাকাউন্ট', icon: Shield },
    { id: 'logs', label: 'N. অ্যাক্টিভিটি লগ', icon: Activity },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar */}
        <aside className="lg:w-64 shrink-0 space-y-4">
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
            <p className="text-xs font-medium text-blue-700 dark:text-blue-400">Dial for Health Admin</p>
            <p className="font-display font-bold text-sm truncate mt-0.5">{firebaseUser.email}</p>
            <button
              type="button"
              onClick={() => void logout()}
              className="mt-3 w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>লগআউট</span>
            </button>
          </div>

          <nav className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-2 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = section === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSection(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg text-left transition-colors cursor-pointer ${
                    active
                      ? 'bg-blue-700 text-white'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Main Workspace */}
        <div className="flex-1 min-w-0 space-y-6">
          {toast && (
            <div className="p-3.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-sm text-blue-900 dark:text-blue-200">
              {toast}
            </div>
          )}

          {section === 'overview' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h1 className="font-display text-2xl font-bold">অ্যাডমিন কন্ট্রোল ড্যাশবোর্ড</h1>
                  <p className="text-xs text-slate-500 mt-0.5">
                    সকল কালেকশন রিয়েল-টাইমে Cloud Firestore-এর সাথে সংযুক্ত
                  </p>
                </div>
                <button
                  type="button"
                  disabled={seeding}
                  onClick={handleSeedData}
                  className="inline-flex items-center gap-2 px-4 py-2 min-h-[40px] text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  <Database className="w-4 h-4" />
                  <span>
                    {seeding ? 'ডেটা সিড হচ্ছে...' : 'প্রাথমিক হেলথকেয়ার ডেটা সিড করুন'}
                  </span>
                </button>
              </div>

              {/* 8 KPI Statistics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'মোট ইউজার', val: users.length },
                  { label: 'মোট ডাক্তার', val: doctors.length },
                  { label: 'মোট হাসপাতাল', val: hospitals.length },
                  { label: 'ডায়াগনস্টিক সেন্টার', val: diagnosticCenters.length },
                  { label: 'মোট অ্যাপয়েন্টমেন্ট', val: appointments.length },
                  { label: 'অপেক্ষমাণ (Pending)', val: pendingCount },
                  { label: 'নিশ্চিত (Confirmed)', val: confirmedCount },
                  { label: 'সক্রিয় বিজ্ঞাপন', val: activeAdsCount },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
                  >
                    <p className="text-xs text-slate-500">{stat.label}</p>
                    <p className="font-display text-2xl font-bold tabular-nums mt-1 text-slate-900 dark:text-white">
                      {stat.val}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'users' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800">
                <h2 className="font-display font-bold text-lg">নিবন্ধিত ইউজার ({users.length})</h2>
              </div>
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {users.map((u) => (
                  <div key={u.uid} className="p-4 flex items-center justify-between gap-4 text-sm">
                    <div>
                      <p className="font-semibold">{u.displayName}</p>
                      <p className="text-xs text-slate-500 font-mono-tabular">
                        {u.userCode || u.uid} · {u.active ? 'Active' : 'Suspended'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void saveEntity('users', u.uid, { active: !u.active }, 'Toggle User Active')
                      }
                      className="px-3 py-1.5 text-xs border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer"
                    >
                      {u.active ? 'নিষ্ক্রিয় করুন' : 'সক্রিয় করুন'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'doctors' && (
            <AdminDoctorsPanel
              doctors={doctors}
              departments={departments}
              hospitals={hospitals}
              onNotify={notify}
            />
          )}

          {section === 'hospitals' && (
            <AdminHospitalsPanel hospitals={hospitals} onNotify={notify} />
          )}

          {section === 'diagnostics' && (
            <AdminDiagnosticsPanel centers={diagnosticCenters} onNotify={notify} />
          )}

          {section === 'appointments' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800">
                <h2 className="font-display font-bold text-lg">
                  সকল অ্যাপয়েন্টমেন্ট ({appointments.length})
                </h2>
              </div>
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {appointments.map((app) => (
                  <div
                    key={app.id}
                    className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div>
                      <p className="font-mono-tabular text-xs text-blue-700 dark:text-blue-400">
                        {app.appointmentCode} · {app.appointmentDate} · {app.appointmentTime}
                      </p>
                      <p className="font-semibold text-sm">
                        {app.patientName} ({app.patientPhone}) → {app.doctorName}
                      </p>
                      <p className="text-xs text-slate-500">
                        {app.hospitalName} · ৳ {app.consultationFee} · Status: {app.status}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {(['pending', 'confirmed', 'completed', 'cancelled'] as AppointmentStatus[]).map(
                        (st) => (
                          <button
                            key={st}
                            type="button"
                            disabled={app.status === st}
                            onClick={() =>
                              void adminUpdateAppointment(app, { status: st }).then(() =>
                                notify(`অ্যাপয়েন্টমেন্ট স্ট্যাটাস ${st} করা হয়েছে।`)
                              )
                            }
                            className={`px-2.5 py-1 text-xs rounded border cursor-pointer ${
                              app.status === st
                                ? 'bg-blue-700 text-white border-blue-700'
                                : 'border-slate-300 dark:border-slate-700'
                            }`}
                          >
                            {st}
                          </button>
                        )
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm('অ্যাপয়েন্টমেন্ট রেকর্ড মুছে ফেলতে চান?')) {
                            void deleteEntity('appointments', app.id, 'Delete Appointment');
                          }
                        }}
                        className="p-1.5 text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'advertisements' && (
            <AdminAdsPanel advertisements={advertisements} onNotify={notify} />
          )}

          {section === 'departments' && (
            <div className="space-y-6">
              <form
                onSubmit={async (e: FormEvent) => {
                  e.preventDefault();
                  await saveEntity(
                    'departments',
                    null,
                    {
                      nameBn: deptNameBn.trim(),
                      nameEn: deptNameEn.trim(),
                      description: deptDesc.trim(),
                      displayOrder: departments.length + 1,
                      active: true,
                    },
                    'Add Department'
                  );
                  setDeptNameBn('');
                  setDeptNameEn('');
                  setDeptDesc('');
                  notify('নতুন বিভাগ যুক্ত হয়েছে।');
                }}
                className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl grid sm:grid-cols-3 gap-3"
              >
                <input required placeholder="বিভাগের নাম (বাংলা)" value={deptNameBn} onChange={(e) => setDeptNameBn(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input required placeholder="Department Name (English)" value={deptNameEn} onChange={(e) => setDeptNameEn(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input placeholder="সংক্ষিপ্ত বিবরণ" value={deptDesc} onChange={(e) => setDeptDesc(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <button type="submit" className="sm:col-span-3 w-fit px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer">
                  বিভাগ যুক্ত করুন
                </button>
              </form>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
                {departments.map((d) => (
                  <div key={d.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">{d.nameBn} ({d.nameEn})</p>
                      <p className="text-xs text-slate-500">{d.description}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => void deleteEntity('departments', d.id, 'Delete Department')}
                      className="p-1.5 text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'notifications' && (
            <form
              onSubmit={async (e: FormEvent) => {
                e.preventDefault();
                await sendAdminNotification({
                  targetUserId: notifTarget,
                  title: notifTitle,
                  message: notifMsg,
                  type: 'announcement',
                });
                setNotifTitle('');
                setNotifMsg('');
                notify('নোটিফিকেশন সফলভাবে পাঠানো হয়েছে।');
              }}
              className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
            >
              <h2 className="font-display font-bold text-lg">ইউজারদের নোটিফিকেশন পাঠান</h2>
              <select value={notifTarget} onChange={(e) => setNotifTarget(e.target.value)} className="w-full min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg">
                <option value="all">সকল নিবন্ধিত ইউজার (All Users)</option>
                {users.map((u) => (
                  <option key={u.uid} value={u.uid}>
                    {u.displayName} ({u.userCode || u.uid})
                  </option>
                ))}
              </select>
              <input required placeholder="নোটিফিকেশন শিরোনাম" value={notifTitle} onChange={(e) => setNotifTitle(e.target.value)} className="w-full min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
              <textarea required rows={3} placeholder="বার্তা লিখুন..." value={notifMsg} onChange={(e) => setNotifMsg(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
              <button type="submit" className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer">
                নোটিফিকেশন প্রেরণ করুন
              </button>
            </form>
          )}

          {section === 'health_tips' && (
            <div className="space-y-6">
              <form
                onSubmit={async (e: FormEvent) => {
                  e.preventDefault();
                  await saveEntity(
                    'health_tips',
                    null,
                    {
                      title: tipTitle.trim(),
                      category: tipCat.trim(),
                      summary: tipSummary.trim(),
                      author: tipAuthor.trim(),
                      published: true,
                    },
                    'Add Health Tip'
                  );
                  setTipTitle('');
                  setTipSummary('');
                  notify('স্বাস্থ্য পরামর্শ যুক্ত হয়েছে।');
                }}
                className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3"
              >
                <h2 className="font-display font-bold text-lg">নতুন স্বাস্থ্য পরামর্শ</h2>
                <div className="grid sm:grid-cols-3 gap-3">
                  <input required placeholder="শিরোনাম" value={tipTitle} onChange={(e) => setTipTitle(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                  <input required placeholder="ক্যাটাগরি" value={tipCat} onChange={(e) => setTipCat(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                  <input placeholder="লেখক / ডাক্তার" value={tipAuthor} onChange={(e) => setTipAuthor(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                </div>
                <textarea required rows={2} placeholder="সংক্ষিপ্ত পরামর্শ" value={tipSummary} onChange={(e) => setTipSummary(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <button type="submit" className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer">
                  প্রকাশ করুন
                </button>
              </form>
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
                {healthTips.map((t) => (
                  <div key={t.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">{t.title}</p>
                      <p className="text-xs text-slate-500">{t.category}</p>
                    </div>
                    <button type="button" onClick={() => void deleteEntity('health_tips', t.id, 'Delete Health Tip')} className="p-1.5 text-red-600 cursor-pointer">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'settings' && (
            <form
              onSubmit={async (e: FormEvent) => {
                e.preventDefault();
                await saveAppSettings(settingsForm);
                notify('ওয়েবসাইট সেটিংস ও কনটেন্ট আপডেট হয়েছে।');
              }}
              className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
            >
              <h2 className="font-display font-bold text-lg">ওয়েবসাইট সেটিংস ও অ্যাপ কনটেন্ট</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                <input value={settingsForm.siteName} onChange={(e) => setSettingsForm({ ...settingsForm, siteName: e.target.value })} placeholder="Site Name" className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input value={settingsForm.tagline} onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })} placeholder="Tagline" className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input value={settingsForm.supportPhone} onChange={(e) => setSettingsForm({ ...settingsForm, supportPhone: e.target.value })} placeholder="Support Phone" className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input value={settingsForm.emergencyHotline} onChange={(e) => setSettingsForm({ ...settingsForm, emergencyHotline: e.target.value })} placeholder="Emergency Hotline" className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input value={settingsForm.whatsappNumber || ''} onChange={(e) => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })} placeholder="WhatsApp Number" className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                <input value={settingsForm.supportEmail || ''} onChange={(e) => setSettingsForm({ ...settingsForm, supportEmail: e.target.value })} placeholder="Support Email" className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
              </div>
              <textarea rows={2} value={settingsForm.aboutContent || ''} onChange={(e) => setSettingsForm({ ...settingsForm, aboutContent: e.target.value })} placeholder="About Us Text" className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
              <textarea rows={2} value={settingsForm.privacyContent || ''} onChange={(e) => setSettingsForm({ ...settingsForm, privacyContent: e.target.value })} placeholder="Privacy Policy Text" className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
              <textarea rows={2} value={settingsForm.termsContent || ''} onChange={(e) => setSettingsForm({ ...settingsForm, termsContent: e.target.value })} placeholder="Terms & Conditions Text" className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
              <button type="submit" className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer">
                সেটিংস সংরক্ষণ করুন
              </button>
            </form>
          )}

          {section === 'admins' && (
            <div className="space-y-6">
              <form
                onSubmit={async (e: FormEvent) => {
                  e.preventDefault();
                  await saveEntity(
                    'admins',
                    newAdminUid.trim(),
                    {
                      uid: newAdminUid.trim(),
                      adminId: newAdminId.trim(),
                      email: newAdminEmail.trim(),
                      name: newAdminName.trim(),
                      roleLevel: newAdminLevel,
                      permissions: ['all'],
                      active: true,
                    },
                    'Add Admin Account'
                  );
                  setNewAdminUid('');
                  setNewAdminId('');
                  setNewAdminEmail('');
                  setNewAdminName('');
                  notify('নতুন অ্যাডমিন অ্যাকাউন্ট যুক্ত হয়েছে।');
                }}
                className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3"
              >
                <h2 className="font-display font-bold text-lg">নতুন অ্যাডমিন অনুমোদন</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input required placeholder="Firebase Auth UID" value={newAdminUid} onChange={(e) => setNewAdminUid(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg font-mono-tabular" />
                  <input required placeholder="Admin ID (যেমন: DFH-ADMIN-02)" value={newAdminId} onChange={(e) => setNewAdminId(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                  <input required type="email" placeholder="ইমেইল" value={newAdminEmail} onChange={(e) => setNewAdminEmail(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                  <input required placeholder="নাম" value={newAdminName} onChange={(e) => setNewAdminName(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
                  <select value={newAdminLevel} onChange={(e) => setNewAdminLevel(e.target.value as 'super_admin' | 'manager' | 'moderator')} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg">
                    <option value="super_admin">Super Admin</option>
                    <option value="manager">Manager</option>
                    <option value="moderator">Moderator</option>
                  </select>
                </div>
                <button type="submit" className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer">
                  অ্যাডমিন যুক্ত করুন
                </button>
              </form>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
                {admins.map((a) => (
                  <div key={a.uid} className="p-4 flex items-center justify-between text-sm">
                    <div>
                      <p className="font-semibold">{a.name} ({a.adminId})</p>
                      <p className="text-xs text-slate-500">{a.email} · {a.roleLevel}</p>
                    </div>
                    {a.uid !== firebaseUser.uid && (
                      <button type="button" onClick={() => void deleteEntity('admins', a.uid, 'Remove Admin')} className="p-1.5 text-red-600 cursor-pointer">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'logs' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800">
                <h2 className="font-display font-bold text-lg">অ্যাডমিন অ্যাক্টিভিটি লগ ({logs.length})</h2>
              </div>
              <div className="divide-y divide-slate-200 dark:divide-slate-800 max-h-[540px] overflow-y-auto">
                {logs.map((log) => (
                  <div key={log.id} className="p-3.5 text-xs flex items-center justify-between gap-4">
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">{log.action}</p>
                      <p className="text-slate-500">
                        {log.actorEmail} · {log.targetCollection} {log.details ? `· ${log.details}` : ''}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
