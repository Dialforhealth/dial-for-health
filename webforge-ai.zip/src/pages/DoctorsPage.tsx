import { useEffect, useState, FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Star, Heart, MapPin, Clock, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import {
  submitDoctorReview,
  subscribeDoctorReviews,
  toggleFavoriteItem,
} from '../services/firestoreService';
import { Doctor, Review } from '../types/healthcare';
import { AdBannerSlot } from '../components/AdBannerSlot';
import { ResilientImage } from '../components/ResilientImage';

interface DoctorsPageProps {
  onBookDoctor: (doctor: Doctor) => void;
  onOpenAuth: () => void;
}

export function DoctorsPage({ onBookDoctor, onOpenAuth }: DoctorsPageProps) {
  const { firebaseUser, userProfile } = useAuth();
  const { doctors, departments, hospitals, language } = useData();
  const [searchParams, setSearchParams] = useSearchParams();
  const isBn = language === 'bn';

  const [queryText, setQueryText] = useState(searchParams.get('q') || '');
  const [selectedDept, setSelectedDept] = useState(searchParams.get('department') || 'all');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [selectedHospital, setSelectedHospital] = useState('all');
  const [maxFee, setMaxFee] = useState('all');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [ratingInput, setRatingInput] = useState(5);
  const [commentInput, setCommentInput] = useState('');
  const [reviewError, setReviewError] = useState<string | null>(null);

  const activeDoctors = doctors.filter((d) => d.active);
  const locations = Array.from(new Set(activeDoctors.map((d) => d.location).filter(Boolean)));

  useEffect(() => {
    const idParam = searchParams.get('id');
    if (idParam) {
      const found = activeDoctors.find((d) => d.id === idParam);
      if (found) setSelectedDoctor(found);
    }
  }, [searchParams, doctors]);

  useEffect(() => {
    if (!selectedDoctor) {
      setReviews([]);
      return;
    }
    const unsub = subscribeDoctorReviews(selectedDoctor.id, setReviews);
    return () => unsub();
  }, [selectedDoctor]);

  const filteredDoctors = activeDoctors.filter((doc) => {
    const q = queryText.trim().toLowerCase();
    const matchesQuery =
      !q ||
      doc.name.toLowerCase().includes(q) ||
      (doc.nameEn || '').toLowerCase().includes(q) ||
      doc.department.toLowerCase().includes(q) ||
      doc.hospitalName.toLowerCase().includes(q) ||
      doc.location.toLowerCase().includes(q);
    const matchesDept = selectedDept === 'all' || doc.department === selectedDept;
    const matchesLoc = selectedLocation === 'all' || doc.location === selectedLocation;
    const matchesHosp = selectedHospital === 'all' || doc.hospitalName === selectedHospital;
    const matchesFee = maxFee === 'all' || doc.consultationFee <= Number(maxFee);
    return matchesQuery && matchesDept && matchesLoc && matchesHosp && matchesFee;
  });

  async function handleReviewSubmit(e: FormEvent) {
    e.preventDefault();
    if (!selectedDoctor) return;
    if (!firebaseUser) {
      onOpenAuth();
      return;
    }
    setReviewError(null);
    if (commentInput.trim().length < 3) {
      setReviewError(isBn ? 'অনুগ্রহ করে আপনার মতামত লিখুন।' : 'Please enter your review.');
      return;
    }
    try {
      await submitDoctorReview({
        doctorId: selectedDoctor.id,
        userId: firebaseUser.uid,
        userName: userProfile?.displayName || firebaseUser.displayName || 'রোগী',
        rating: ratingInput,
        comment: commentInput,
      });
      setCommentInput('');
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : String(err));
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-slate-900 dark:text-white">
          {isBn ? 'বিশেষজ্ঞ ডাক্তার ডিরেক্টরি' : 'Specialist Doctor Directory'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          {isBn
            ? 'নাম, বিভাগ, হাসপাতাল, লোকেশন ও পরামর্শ ফি অনুযায়ী ডাক্তার খুঁজুন এবং অনলাইনে অ্যাপয়েন্টমেন্ট নিন'
            : 'Filter doctors by specialty, hospital, location, and consultation fee'}
        </p>
      </div>

      <AdBannerSlot placement="doctor_banner" />

      {/* Search & Multi-Filter Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="relative lg:col-span-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder={isBn ? 'ডাক্তারের নাম, ডিগ্রি বা এলাকা...' : 'Doctor name, degree, city...'}
            className="w-full min-h-[42px] pl-9 pr-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
          />
        </div>

        <select
          value={selectedDept}
          onChange={(e) => setSelectedDept(e.target.value)}
          aria-label="Filter by Department"
          className="min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
        >
          <option value="all">{isBn ? 'সকল বিভাগ' : 'All Departments'}</option>
          {departments.map((d) => (
            <option key={d.id} value={d.nameBn}>
              {isBn ? d.nameBn : d.nameEn}
            </option>
          ))}
        </select>

        <select
          value={selectedLocation}
          onChange={(e) => setSelectedLocation(e.target.value)}
          aria-label="Filter by Location"
          className="min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
        >
          <option value="all">{isBn ? 'সকল শহর' : 'All Locations'}</option>
          {locations.map((loc) => (
            <option key={loc} value={loc}>
              {loc}
            </option>
          ))}
        </select>

        <select
          value={maxFee}
          onChange={(e) => setMaxFee(e.target.value)}
          aria-label="Filter by Fee"
          className="min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
        >
          <option value="all">{isBn ? 'যেকোনো ফি' : 'Any Fee'}</option>
          <option value="800">{isBn ? '৳ ৮০০ এর মধ্যে' : 'Up to ৳ 800'}</option>
          <option value="1200">{isBn ? '৳ ১,২০০ এর মধ্যে' : 'Up to ৳ 1,200'}</option>
          <option value="2000">{isBn ? '৳ ২,০০০ এর মধ্যে' : 'Up to ৳ 2,000'}</option>
        </select>

        {hospitals.length > 0 && (
          <select
            value={selectedHospital}
            onChange={(e) => setSelectedHospital(e.target.value)}
            aria-label="Filter by Hospital"
            className="sm:col-span-2 lg:col-span-5 min-h-[40px] px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 rounded-lg"
          >
            <option value="all">{isBn ? 'সকল হাসপাতাল / চেম্বার' : 'All Hospitals'}</option>
            {hospitals.map((h) => (
              <option key={h.id} value={h.name}>
                {h.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Results Grid */}
      {filteredDoctors.length === 0 ? (
        <div className="p-10 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {isBn
              ? 'আপনার সার্চের সাথে মিলে এমন কোনো ডাক্তার পাওয়া যায়নি।'
              : 'No matching doctors found.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doc) => {
            const isFav = userProfile?.favoriteDoctorIds?.includes(doc.id) ?? false;
            return (
              <article
                key={doc.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start gap-4">
                    <div className="w-20 h-20 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0">
                      <ResilientImage
                        src={doc.photoUrl}
                        alt={doc.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-xs text-slate-500">
                          {doc.department} · {doc.experienceYears || 5}+ {isBn ? 'বছর' : 'yrs'}
                        </p>
                        <button
                          type="button"
                          onClick={() => {
                            if (!firebaseUser) {
                              onOpenAuth();
                              return;
                            }
                            void toggleFavoriteItem(firebaseUser.uid, 'doctor', doc.id, isFav);
                          }}
                          className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                        >
                          <Heart className={`w-4 h-4 ${isFav ? 'fill-red-600 text-red-600' : ''}`} />
                        </button>
                      </div>
                      <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                        {doc.name}
                      </h2>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">{doc.degree}</p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                    <p className="flex items-center gap-1.5 font-medium text-slate-800 dark:text-slate-200">
                      <MapPin className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                      <span>
                        {doc.hospitalName} ({doc.location})
                      </span>
                    </p>
                    {doc.visitingSchedule && (
                      <p className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                        <span>{doc.visitingSchedule}</span>
                      </p>
                    )}
                    <div className="flex items-center justify-between pt-1">
                      <span className="inline-flex items-center gap-1 tabular-nums">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                        {(doc.rating || 5.0).toFixed(1)}
                      </span>
                      <span className="font-semibold text-blue-800 dark:text-blue-400 tabular-nums">
                        ৳ {doc.consultationFee}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onBookDoctor(doc)}
                    className="flex-1 min-h-[40px] px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                  >
                    {isBn ? 'অ্যাপয়েন্টমেন্ট নিন' : 'Book Appointment'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedDoctor(doc)}
                    className="px-3.5 py-2 min-h-[40px] text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                  >
                    {isBn ? 'প্রোফাইল ও রিভিউ' : 'Profile & Reviews'}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Doctor Detail & Reviews Modal */}
      {selectedDoctor && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
          onClick={() => {
            setSelectedDoctor(null);
            setSearchParams({});
          }}
        >
          <div
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl p-6 space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-start gap-4">
                <div className="w-20 h-20 rounded-lg overflow-hidden border border-slate-200 shrink-0">
                  <ResilientImage
                    src={selectedDoctor.photoUrl}
                    alt={selectedDoctor.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="text-xs font-medium text-blue-700 dark:text-blue-400">
                    {selectedDoctor.department}
                  </p>
                  <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                    {selectedDoctor.name}
                  </h2>
                  <p className="text-sm text-slate-600 dark:text-slate-300">{selectedDoctor.degree}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedDoctor(null);
                  setSearchParams({});
                }}
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-lg space-y-1">
                <p className="text-xs text-slate-500">{isBn ? 'হাসপাতাল ও চেম্বার' : 'Hospital & Chamber'}</p>
                <p className="font-semibold">{selectedDoctor.hospitalName}</p>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  {selectedDoctor.chamberAddress || selectedDoctor.location}
                </p>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-lg space-y-1">
                <p className="text-xs text-slate-500">{isBn ? 'ভিজিটিং সময় ও ফি' : 'Schedule & Fee'}</p>
                <p className="font-semibold tabular-nums">৳ {selectedDoctor.consultationFee}</p>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  {selectedDoctor.visitingSchedule}
                </p>
              </div>
            </div>

            {selectedDoctor.qualification && (
              <p className="text-sm text-slate-600 dark:text-slate-300">
                <strong>{isBn ? 'পেশাগত যোগ্যতা:' : 'Qualification:'}</strong> {selectedDoctor.qualification}
              </p>
            )}

            <button
              type="button"
              onClick={() => {
                const d = selectedDoctor;
                setSelectedDoctor(null);
                onBookDoctor(d);
              }}
              className="w-full min-h-[44px] px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
            >
              {isBn ? 'এখনই অ্যাপয়েন্টমেন্ট বুক করুন' : 'Book Appointment Now'}
            </button>

            {/* Patient Reviews */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
              <h3 className="font-display font-bold text-lg">
                {isBn ? `রোগীদের রিভিউ (${reviews.length})` : `Patient Reviews (${reviews.length})`}
              </h3>

              <form onSubmit={handleReviewSubmit} className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-lg">
                {reviewError && <p className="text-xs text-red-600">{reviewError}</p>}
                <div className="flex items-center justify-between gap-4">
                  <label className="text-xs font-medium">
                    {isBn ? 'আপনার রেটিং দিন' : 'Your Rating'}
                  </label>
                  <select
                    value={ratingInput}
                    onChange={(e) => setRatingInput(Number(e.target.value))}
                    className="px-2.5 py-1 text-xs border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900"
                  >
                    <option value={5}>5 / 5</option>
                    <option value={4}>4 / 5</option>
                    <option value={3}>3 / 5</option>
                    <option value={2}>2 / 5</option>
                    <option value={1}>1 / 5</option>
                  </select>
                </div>
                <textarea
                  rows={2}
                  value={commentInput}
                  onChange={(e) => setCommentInput(e.target.value)}
                  placeholder={isBn ? 'চিকিৎসা ও পরামর্শের অভিজ্ঞতা লিখুন...' : 'Share your consultation experience...'}
                  className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-lg"
                />
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  {isBn ? 'রিভিউ জমা দিন' : 'Submit Review'}
                </button>
              </form>

              {reviews.length === 0 ? (
                <p className="text-xs text-slate-500">
                  {isBn ? 'এখনো কোনো রিভিউ জমা পড়েনি।' : 'No reviews submitted yet.'}
                </p>
              ) : (
                <div className="space-y-3">
                  {reviews.map((rev) => (
                    <div key={rev.id} className="p-3 border border-slate-200 dark:border-slate-800 rounded-lg">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold">{rev.userName}</span>
                        <span className="inline-flex items-center gap-1 tabular-nums text-amber-600">
                          <Star className="w-3.5 h-3.5 fill-amber-400" /> {rev.rating}.0
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-300">{rev.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
