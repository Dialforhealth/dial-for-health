import { Component, ReactNode, useEffect, useState } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { Doctor } from './types/healthcare';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { AppointmentBookingModal } from './components/AppointmentBookingModal';
import { HomePage } from './pages/HomePage';
import { DoctorsPage } from './pages/DoctorsPage';
import { HospitalsPage } from './pages/HospitalsPage';
import { DiagnosticsPage } from './pages/DiagnosticsPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { AboutPage, ContactPage, PolicyPage } from './pages/StaticInfoPages';
import { UserDashboard } from './pages/UserDashboard';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboard } from './pages/AdminDashboard';

class ErrorBoundary extends Component<
  { children: ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50 text-slate-900">
          <div className="max-w-lg p-6 bg-white border border-slate-200 rounded-xl space-y-3">
            <h1 className="font-display text-xl font-bold text-red-700">
              সিস্টেমে একটি ত্রুটি ঘটেছে
            </h1>
            <p className="text-xs text-slate-600 break-words">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg cursor-pointer"
            >
              পুনরায় লোড করুন
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function RouteSeoSync() {
  const { pathname } = useLocation();
  useEffect(() => {
    const titles: Record<string, string> = {
      '/': 'Dial for Health – Your Health, Our Priority | বাংলাদেশের স্বাস্থ্যসেবা প্ল্যাটফর্ম',
      '/doctors': 'বিশেষজ্ঞ ডাক্তার ডিরেক্টরি | Dial for Health',
      '/hospitals': 'হাসপাতাল ডিরেক্টরি | Dial for Health',
      '/diagnostic-centers': 'ডায়াগনস্টিক সেন্টার ও টেস্ট মূল্য | Dial for Health',
      '/appointments': 'অনলাইন ডাক্তার অ্যাপয়েন্টমেন্ট | Dial for Health',
      '/dashboard': 'ইউজার ড্যাশবোর্ড | Dial for Health',
      '/admin/login': 'অ্যাডমিন লগইন | Dial for Health Admin',
      '/admin/dashboard': 'অ্যাডমিন ড্যাশবোর্ড | Dial for Health Admin',
      '/about': 'আমাদের সম্পর্কে | Dial for Health',
      '/contact': 'যোগাযোগ ও সাপোর্ট | Dial for Health',
      '/privacy': 'গোপনীয়তা নীতি | Dial for Health',
      '/terms': 'ব্যবহারের শর্তাবলি | Dial for Health',
      '/faq': 'সচরাচর জিজ্ঞাসা | Dial for Health',
    };
    document.title = titles[pathname] || 'Dial for Health – Your Health, Our Priority';
  }, [pathname]);
  return null;
}

function AppShell() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [bookingDoctor, setBookingDoctor] = useState<Doctor | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <RouteSeoSync />
      <Header onOpenAuth={() => setAuthModalOpen(true)} />

      <main className="flex-1">
        <Routes>
          <Route
            path="/"
            element={
              <HomePage
                onBookDoctor={(doc) => setBookingDoctor(doc)}
                onOpenAuth={() => setAuthModalOpen(true)}
              />
            }
          />
          <Route
            path="/doctors"
            element={
              <DoctorsPage
                onBookDoctor={(doc) => setBookingDoctor(doc)}
                onOpenAuth={() => setAuthModalOpen(true)}
              />
            }
          />
          <Route
            path="/hospitals"
            element={<HospitalsPage onOpenAuth={() => setAuthModalOpen(true)} />}
          />
          <Route path="/diagnostic-centers" element={<DiagnosticsPage />} />
          <Route
            path="/appointments"
            element={<AppointmentsPage onBookDoctor={(doc) => setBookingDoctor(doc)} />}
          />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/privacy" element={<PolicyPage mode="privacy" />} />
          <Route path="/terms" element={<PolicyPage mode="terms" />} />
          <Route path="/faq" element={<PolicyPage mode="faq" />} />
          <Route
            path="/dashboard"
            element={
              <UserDashboard
                onOpenAuth={() => setAuthModalOpen(true)}
                onBookDoctor={(doc) => setBookingDoctor(doc)}
              />
            }
          />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
        </Routes>
      </main>

      <Footer />

      <AuthModal open={authModalOpen} onClose={() => setAuthModalOpen(false)} />
      <AppointmentBookingModal
        doctor={bookingDoctor}
        onClose={() => setBookingDoctor(null)}
        onRequireAuth={() => {
          setBookingDoctor(null);
          setAuthModalOpen(true);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <DataProvider>
          <BrowserRouter>
            <AppShell />
          </BrowserRouter>
        </DataProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
