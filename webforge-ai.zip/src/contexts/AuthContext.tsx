import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react';
import {
  ConfirmationResult,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  RecaptchaVerifier,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPhoneNumber,
  signInWithPopup,
  signOut,
  updatePassword,
  updateProfile,
  User,
} from 'firebase/auth';
import { doc, getDoc, onSnapshot, serverTimestamp, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase';
import { ensureUserProfile } from '../services/firestoreService';
import { AdminAccount, UserPrivateInfo, UserPublicProfile, UserRole } from '../types/healthcare';

interface AuthContextValue {
  firebaseUser: User | null;
  authReady: boolean;
  role: UserRole | null;
  userProfile: UserPublicProfile | null;
  userPrivate: UserPrivateInfo | null;
  adminAccount: AdminAccount | null;
  loginWithGoogle: () => Promise<UserRole>;
  loginWithEmail: (email: string, password: string) => Promise<UserRole>;
  registerWithEmail: (name: string, email: string, password: string) => Promise<UserRole>;
  sendResetEmail: (email: string) => Promise<void>;
  changePassword: (newPassword: string) => Promise<void>;
  sendPhoneOtp: (phoneNumber: string, recaptchaContainerId: string) => Promise<ConfirmationResult>;
  confirmPhoneOtp: (
    confirmation: ConfirmationResult,
    code: string,
    displayName?: string
  ) => Promise<UserRole>;
  logout: () => Promise<void>;
  refreshRole: () => Promise<UserRole | null>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const BOOTSTRAPPED_ADMIN_EMAIL = 'sayed.gemini26@gmail.com';

async function resolveUserRole(user: User): Promise<{
  role: UserRole;
  adminAccount: AdminAccount | null;
}> {
  const adminRef = doc(db, 'admins', user.uid);
  try {
    const adminSnap = await getDoc(adminRef);
    if (adminSnap.exists() && adminSnap.data()?.active === true) {
      return {
        role: 'admin',
        adminAccount: { uid: user.uid, ...adminSnap.data() } as AdminAccount,
      };
    }

    // Bootstrapped primary administrator email verified via Firebase Auth
    if (user.email === BOOTSTRAPPED_ADMIN_EMAIL && user.emailVerified) {
      const now = serverTimestamp();
      const adminPayload: Omit<AdminAccount, 'createdAt' | 'updatedAt'> & {
        createdAt: unknown;
        updatedAt: unknown;
      } = {
        uid: user.uid,
        adminId: 'DFH-ADMIN-01',
        email: user.email,
        name: user.displayName || 'System Administrator',
        roleLevel: 'super_admin',
        permissions: ['all'],
        active: true,
        createdAt: now,
        updatedAt: now,
      };
      await setDoc(adminRef, adminPayload, { merge: true });
      return {
        role: 'admin',
        adminAccount: adminPayload as AdminAccount,
      };
    }
  } catch (err) {
    console.warn('Admin role check fallback to regular user:', err);
  }

  await ensureUserProfile({
    uid: user.uid,
    displayName: user.displayName || user.phoneNumber || 'রোগী',
    email: user.email,
    phone: user.phoneNumber,
    photoUrl: user.photoURL,
  });

  return { role: 'user', adminAccount: null };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [role, setRole] = useState<UserRole | null>(null);
  const [userProfile, setUserProfile] = useState<UserPublicProfile | null>(null);
  const [userPrivate, setUserPrivate] = useState<UserPrivateInfo | null>(null);
  const [adminAccount, setAdminAccount] = useState<AdminAccount | null>(null);

  useEffect(() => {
    let unsubPublic: (() => void) | null = null;
    let unsubPrivate: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubPublic) unsubPublic();
      if (unsubPrivate) unsubPrivate();

      setFirebaseUser(user);

      if (!user) {
        setRole(null);
        setUserProfile(null);
        setUserPrivate(null);
        setAdminAccount(null);
        setAuthReady(true);
        return;
      }

      try {
        const resolved = await resolveUserRole(user);
        setRole(resolved.role);
        setAdminAccount(resolved.adminAccount);

        unsubPublic = onSnapshot(
          doc(db, 'users', user.uid),
          (snap) => {
            if (snap.exists()) {
              setUserProfile({ uid: snap.id, ...snap.data() } as UserPublicProfile);
            }
          },
          () => {}
        );

        unsubPrivate = onSnapshot(
          doc(db, 'users', user.uid, 'private', 'contact'),
          (snap) => {
            if (snap.exists()) {
              setUserPrivate({ uid: user.uid, ...snap.data() } as UserPrivateInfo);
            }
          },
          () => {}
        );
      } catch (error) {
        console.error('Auth resolution error:', error);
      } finally {
        setAuthReady(true);
      }
    });

    return () => {
      unsubAuth();
      if (unsubPublic) unsubPublic();
      if (unsubPrivate) unsubPrivate();
    };
  }, []);

  async function loginWithGoogle(): Promise<UserRole> {
    const cred = await signInWithPopup(auth, googleProvider);
    const resolved = await resolveUserRole(cred.user);
    setRole(resolved.role);
    setAdminAccount(resolved.adminAccount);
    return resolved.role;
  }

  async function loginWithEmail(email: string, password: string): Promise<UserRole> {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    const resolved = await resolveUserRole(cred.user);
    setRole(resolved.role);
    setAdminAccount(resolved.adminAccount);
    return resolved.role;
  }

  async function registerWithEmail(
    name: string,
    email: string,
    password: string
  ): Promise<UserRole> {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    await updateProfile(cred.user, { displayName: name.trim() });
    await sendEmailVerification(cred.user).catch(() => {});
    const resolved = await resolveUserRole(cred.user);
    setRole(resolved.role);
    setAdminAccount(resolved.adminAccount);
    return resolved.role;
  }

  async function sendResetEmail(email: string) {
    await sendPasswordResetEmail(auth, email.trim());
  }

  async function changePassword(newPassword: string) {
    if (!auth.currentUser) throw new Error('অ্যাকাউন্ট লগইন করা নেই।');
    await updatePassword(auth.currentUser, newPassword);
  }

  async function sendPhoneOtp(
    phoneNumber: string,
    recaptchaContainerId: string
  ): Promise<ConfirmationResult> {
    const existingVerifier = (window as unknown as { recaptchaVerifier?: RecaptchaVerifier })
      .recaptchaVerifier;
    if (existingVerifier) {
      existingVerifier.clear();
    }
    const verifier = new RecaptchaVerifier(auth, recaptchaContainerId, {
      size: 'invisible',
    });
    (window as unknown as { recaptchaVerifier?: RecaptchaVerifier }).recaptchaVerifier = verifier;
    return signInWithPhoneNumber(auth, phoneNumber.trim(), verifier);
  }

  async function confirmPhoneOtp(
    confirmation: ConfirmationResult,
    code: string,
    displayName?: string
  ): Promise<UserRole> {
    const cred = await confirmation.confirm(code.trim());
    if (displayName && !cred.user.displayName) {
      await updateProfile(cred.user, { displayName: displayName.trim() });
    }
    const resolved = await resolveUserRole(cred.user);
    setRole(resolved.role);
    setAdminAccount(resolved.adminAccount);
    return resolved.role;
  }

  async function logout() {
    await signOut(auth);
  }

  async function refreshRole(): Promise<UserRole | null> {
    if (!auth.currentUser) return null;
    const resolved = await resolveUserRole(auth.currentUser);
    setRole(resolved.role);
    setAdminAccount(resolved.adminAccount);
    return resolved.role;
  }

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        authReady,
        role,
        userProfile,
        userPrivate,
        adminAccount,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        sendResetEmail,
        changePassword,
        sendPhoneOtp,
        confirmPhoneOtp,
        logout,
        refreshRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
