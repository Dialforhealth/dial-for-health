import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  subscribeCollection,
  subscribeUserNotifications,
} from '../services/firestoreService';
import {
  Advertisement,
  AppNotification,
  AppSettings,
  Department,
  DiagnosticCenter,
  Doctor,
  HealthTip,
  Hospital,
  LanguageCode,
} from '../types/healthcare';
import { useAuth } from './AuthContext';

interface DataContextValue {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  doctors: Doctor[];
  hospitals: Hospital[];
  diagnosticCenters: DiagnosticCenter[];
  departments: Department[];
  advertisements: Advertisement[];
  healthTips: HealthTip[];
  notifications: AppNotification[];
  appSettings: AppSettings;
  dataLoading: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  siteName: 'Dial for Health',
  tagline: 'Your Health, Our Priority',
  supportPhone: '+880 1700-112233',
  emergencyHotline: '999 / 16263',
  whatsappNumber: '+8801700112233',
  supportEmail: 'support@dialforhealth.bd',
  address: 'বনানী, ঢাকা ১২১৩, বাংলাদেশ',
  aboutContent:
    'Dial for Health বাংলাদেশের রোগী, বিশেষজ্ঞ চিকিৎসক, হাসপাতাল ও ডায়াগনস্টিক সেন্টারের মধ্যে নির্ভরযোগ্য ডিজিটাল সেতুবন্ধন।',
  privacyContent:
    'রোগীর ব্যক্তিগত তথ্য, মোবাইল নম্বর এবং অ্যাপয়েন্টমেন্টের বিবরণ সম্পূর্ণ এনক্রিপ্টেড Firebase অবকাঠামোতে সংরক্ষিত থাকে।',
  termsContent:
    'ডাক্তারদের ভিজিটিং সময়সূচি সংশ্লিষ্ট হাসপাতাল বা চেম্বারের নীতিমালা অনুযায়ী পরিবর্তিত হতে পারে। জরুরি অবস্থায় সরাসরি ৯৯৯ বা নিকটস্থ ইমার্জেন্সিতে যোগাযোগ করুন।',
};

const DataContext = createContext<DataContextValue | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const { firebaseUser } = useAuth();
  const [language, setLanguageState] = useState<LanguageCode>('bn');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [diagnosticCenters, setDiagnosticCenters] = useState<DiagnosticCenter[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [advertisements, setAdvertisements] = useState<Advertisement[]>([]);
  const [healthTips, setHealthTips] = useState<HealthTip[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  function setLanguage(lang: LanguageCode) {
    setLanguageState(lang);
    document.documentElement.lang = lang;
  }

  function toggleTheme() {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }

  useEffect(() => {
    const unsubs: Array<() => void> = [];

    try {
      unsubs.push(
        subscribeCollection<Doctor>('doctors', (items) => {
          setDoctors(items);
          setDataLoading(false);
        })
      );
      unsubs.push(subscribeCollection<Hospital>('hospitals', setHospitals));
      unsubs.push(
        subscribeCollection<DiagnosticCenter>('diagnostic_centers', setDiagnosticCenters)
      );
      unsubs.push(subscribeCollection<Department>('departments', setDepartments));
      unsubs.push(subscribeCollection<Advertisement>('advertisements', setAdvertisements));
      unsubs.push(subscribeCollection<HealthTip>('health_tips', setHealthTips));
      unsubs.push(
        onSnapshot(
          doc(db, 'app_settings', 'global'),
          (snap) => {
            if (snap.exists()) {
              setAppSettings({ ...DEFAULT_SETTINGS, ...(snap.data() as AppSettings) });
            }
          },
          () => {}
        )
      );
    } catch (error) {
      console.error('Data subscription setup error:', error);
      setDataLoading(false);
    }

    return () => {
      unsubs.forEach((u) => u());
    };
  }, []);

  useEffect(() => {
    if (!firebaseUser) {
      setNotifications([]);
      return;
    }
    const unsub = subscribeUserNotifications(firebaseUser.uid, setNotifications);
    return () => unsub();
  }, [firebaseUser]);

  return (
    <DataContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        toggleTheme,
        doctors,
        hospitals,
        diagnosticCenters,
        departments,
        advertisements,
        healthTips,
        notifications,
        appSettings,
        dataLoading,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used inside DataProvider');
  return ctx;
}
