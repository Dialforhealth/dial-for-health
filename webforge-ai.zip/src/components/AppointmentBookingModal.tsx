import { useEffect, useState, FormEvent } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { X, AlertCircle, CheckCircle2, Calendar, Clock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { db } from '../lib/firebase';
import { bookAppointmentTransaction } from '../services/firestoreService';
import { Doctor } from '../types/healthcare';

interface AppointmentBookingModalProps {
  doctor: Doctor | null;
  onClose: () => void;
  onRequireAuth: () => void;
}

const DEFAULT_SLOTS = ['10:30 AM', '11:30 AM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM'];

export function AppointmentBookingModal({
  doctor,
  onClose,
  onRequireAuth,
}: AppointmentBookingModalProps) {
  const { firebaseUser, userProfile, userPrivate } = useAuth();
  const { language } = useData();
  const isBn = language === 'bn';

  const todayStr = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState(todayStr);
  const [selectedTime, setSelectedTime] = useState('');
  const [bookedTimes, setBookedTimes] = useState<string[]>([]);
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientGender, setPatientGender] = useState<'male' | 'female' | 'other'>('male');
  const [patientPhone, setPatientPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedCode, setConfirmedCode] = useState<string | null>(null);

  useEffect(() => {
    if (userProfile?.displayName && !patientName) {
      setPatientName(userProfile.displayName);
    }
    if (userPrivate?.phone && !patientPhone) {
      setPatientPhone(userPrivate.phone);
    }
  }, [userProfile, userPrivate]);

  // Real-time double-booking slot monitor
  useEffect(() => {
    if (!doctor || !firebaseUser) {
      setBookedTimes([]);
      return;
    }
    const q = query(
      collection(db, 'appointment_slots'),
      where('doctorId', '==', doctor.id),
      where('appointmentDate', '==', date)
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const times = snap.docs.map((d) => String(d.data().appointmentTime || ''));
        setBookedTimes(times);
      },
      () => {}
    );
    return () => unsub();
  }, [doctor, date, firebaseUser]);

  if (!doctor) return null;

  const slots = doctor.availableSlots && doctor.availableSlots.length > 0
    ? doctor.availableSlots
    : DEFAULT_SLOTS;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!doctor) return;
    if (!firebaseUser) {
      onRequireAuth();
      return;
    }
    setError(null);

    if (!selectedTime) {
      setError(isBn ? 'অনুগ্রহ করে একটি সময় স্লট নির্বাচন করুন।' : 'Please select an available time slot.');
      return;
    }
    if (patientName.trim().length < 2) {
      setError(isBn ? 'রোগীর পূর্ণ নাম লিখুন।' : 'Please enter patient name.');
      return;
    }
    const ageNum = Number(patientAge);
    if (!ageNum || ageNum < 1 || ageNum > 125) {
      setError(isBn ? 'সঠিক বয়স লিখুন।' : 'Please enter a valid age.');
      return;
    }
    if (!/^[+]?[\d\s-]{8,18}$/.test(patientPhone.trim())) {
      setError(isBn ? 'সঠিক মোবাইল নম্বর দিন।' : 'Please enter a valid mobile number.');
      return;
    }

    setBusy(true);
    try {
      const res = await bookAppointmentTransaction({
        userId: firebaseUser.uid,
        doctorId: doctor.id,
        doctorName: doctor.name,
        hospitalName: doctor.hospitalName,
        appointmentDate: date,
        appointmentTime: selectedTime,
        patientName,
        patientAge: ageNum,
        patientGender,
        patientPhone,
        consultationFee: doctor.consultationFee,
        notes,
      });
      setConfirmedCode(res.appointmentCode);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl max-h-[92vh] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <p className="text-xs font-medium text-blue-700 dark:text-blue-400">
              {doctor.department} · ৳ {doctor.consultationFee.toLocaleString('en-US')}
            </p>
            <h2
              id="booking-modal-title"
              className="font-display text-xl font-bold text-slate-900 dark:text-white mt-0.5"
            >
              {doctor.name}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {doctor.hospitalName} · {doctor.location}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 inline-flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 sm:p-6">
          {!firebaseUser ? (
            <div className="text-center py-6 space-y-4">
              <p className="text-sm text-slate-600 dark:text-slate-300">
                {isBn
                  ? 'অনলাইন অ্যাপয়েন্টমেন্ট বুক করতে এবং আপনার বুকিং ইতিহাস সংরক্ষণ করতে অনুগ্রহ করে লগইন করুন।'
                  : 'Please sign in to confirm your online appointment and manage your booking history.'}
              </p>
              <button
                type="button"
                onClick={onRequireAuth}
                className="px-6 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
              >
                {isBn ? 'লগইন / নিবন্ধন করুন' : 'Login / Register'}
              </button>
            </div>
          ) : confirmedCode ? (
            <div className="py-4 space-y-4">
              <div className="flex items-start gap-3 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                <CheckCircle2 className="w-6 h-6 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                    {isBn ? 'অ্যাপয়েন্টমেন্ট অনুরোধ নিশ্চিত হয়েছে' : 'Appointment Request Submitted'}
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                    {isBn ? 'আপনার ইউনিক অ্যাপয়েন্টমেন্ট আইডি:' : 'Your Unique Appointment ID:'}{' '}
                    <strong className="font-mono-tabular text-blue-800 dark:text-blue-300">
                      {confirmedCode}
                    </strong>
                  </p>
                </div>
              </div>
              <dl className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-sm">
                <div className="flex justify-between px-4 py-2.5">
                  <dt className="text-slate-500">{isBn ? 'তারিখ ও সময়' : 'Date & Time'}</dt>
                  <dd className="font-medium tabular-nums">
                    {date} · {selectedTime}
                  </dd>
                </div>
                <div className="flex justify-between px-4 py-2.5">
                  <dt className="text-slate-500">{isBn ? 'রোগী' : 'Patient'}</dt>
                  <dd className="font-medium">{patientName}</dd>
                </div>
                <div className="flex justify-between px-4 py-2.5">
                  <dt className="text-slate-500">{isBn ? 'পরামর্শ ফি' : 'Consultation Fee'}</dt>
                  <dd className="font-medium tabular-nums">৳ {doctor.consultationFee}</dd>
                </div>
              </dl>
              <button
                type="button"
                onClick={onClose}
                className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
              >
                {isBn ? 'সম্পন্ন করুন' : 'Done'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div
                  role="alert"
                  className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-xs text-red-800 dark:text-red-300"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-700" />
                  <span>{isBn ? 'অ্যাপয়েন্টমেন্টের তারিখ' : 'Appointment Date'}</span>
                </label>
                <input
                  type="date"
                  min={todayStr}
                  required
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    setSelectedTime('');
                  }}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>

              <div>
                <label className="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                  <Clock className="w-3.5 h-3.5 text-blue-700" />
                  <span>{isBn ? 'উপলব্ধ সময় স্লট নির্বাচন করুন' : 'Select Available Time Slot'}</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {slots.map((slot) => {
                    const isBooked = bookedTimes.includes(slot);
                    const isSelected = selectedTime === slot;
                    return (
                      <button
                        key={slot}
                        type="button"
                        disabled={isBooked}
                        onClick={() => setSelectedTime(slot)}
                        className={`px-3 py-2 min-h-[40px] text-xs font-medium rounded-lg border transition-colors tabular-nums ${
                          isBooked
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-800 line-through cursor-not-allowed'
                            : isSelected
                            ? 'bg-blue-700 text-white border-blue-700 cursor-pointer'
                            : 'bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700 hover:border-blue-600 cursor-pointer'
                        }`}
                      >
                        {slot}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {isBn ? 'রোগীর নাম' : 'Patient Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder={isBn ? 'পূর্ণ নাম' : 'Full name'}
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {isBn ? 'মোবাইল নম্বর' : 'Mobile Number'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    placeholder="+88017..."
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {isBn ? 'বয়স (বছর)' : 'Age'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={125}
                    required
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value)}
                    placeholder="32"
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {isBn ? 'লিঙ্গ' : 'Gender'}
                  </label>
                  <select
                    value={patientGender}
                    onChange={(e) =>
                      setPatientGender(e.target.value as 'male' | 'female' | 'other')
                    }
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  >
                    <option value="male">{isBn ? 'পুরুষ' : 'Male'}</option>
                    <option value="female">{isBn ? 'মহিলা' : 'Female'}</option>
                    <option value="other">{isBn ? 'অন্যান্য' : 'Other'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {isBn ? 'স্বাস্থ্য সমস্যা / নোট (ঐচ্ছিক)' : 'Symptoms / Notes (Optional)'}
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>

              <button
                type="submit"
                disabled={busy}
                className="w-full min-h-[46px] px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                {busy
                  ? isBn
                    ? 'বুকিং সম্পন্ন হচ্ছে...'
                    : 'Confirming Slot...'
                  : isBn
                  ? `অ্যাপয়েন্টমেন্ট নিশ্চিত করুন (৳ ${doctor.consultationFee})`
                  : `Confirm Appointment (৳ ${doctor.consultationFee})`}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
