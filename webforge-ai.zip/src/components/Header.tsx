import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Bell, Menu, Moon, Sun, X, CheckCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { t } from '../lib/i18n';
import { markNotificationRead } from '../services/firestoreService';

interface HeaderProps {
  onOpenAuth: () => void;
}

export function Header({ onOpenAuth }: HeaderProps) {
  const { firebaseUser, role, userProfile } = useAuth();
  const { language, setLanguage, theme, toggleTheme, notifications } = useData();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const navigate = useNavigate();
  const copy = t(language);

  const unreadCount = firebaseUser
    ? notifications.filter((n) => !n.readBy?.includes(firebaseUser.uid)).length
    : 0;

  const navItems = [
    { to: '/', label: copy.nav.home },
    { to: '/doctors', label: copy.nav.doctors },
    { to: '/hospitals', label: copy.nav.hospitals },
    { to: '/diagnostic-centers', label: copy.nav.diagnostics },
    { to: '/appointments', label: copy.nav.appointments },
  ];

  function handlePrimaryAction() {
    if (!firebaseUser) {
      onOpenAuth();
      return;
    }
    if (role === 'admin') {
      navigate('/admin/dashboard');
    } else {
      navigate('/dashboard');
    }
  }

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text wordmark */}
        <Link
          to="/"
          className="font-display text-xl font-bold tracking-tight text-blue-800 dark:text-blue-400 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 rounded-sm"
        >
          Dial for Health
        </Link>

        {/* Zone 2: Clean single-line navigation links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300"
        >
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `py-1 border-b-2 transition-colors duration-150 whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'text-blue-800 dark:text-blue-400 border-blue-800 dark:border-blue-400 font-semibold'
                    : 'border-transparent hover:text-slate-900 dark:hover:text-white hover:border-blue-700'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Zone 3: Primary action + mobile toggle */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handlePrimaryAction}
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 min-h-[40px] text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-700"
          >
            {!firebaseUser
              ? copy.actions.login
              : role === 'admin'
              ? copy.actions.adminPanel
              : userProfile?.displayName?.split(' ')[0] || copy.actions.dashboard}
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label="Toggle Menu"
            className="lg:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Sub-strip utility bar for Language, Theme, Secondary Links & Notifications */}
      <div className="hidden lg:block bg-slate-50 dark:bg-slate-900 border-t border-slate-200/80 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-9 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-5">
            <span>{copy.tagline}</span>
            <span aria-hidden="true">·</span>
            <Link to="/about" className="hover:text-blue-700 dark:hover:text-blue-400 whitespace-nowrap">
              {copy.nav.about}
            </Link>
            <Link to="/contact" className="hover:text-blue-700 dark:hover:text-blue-400 whitespace-nowrap">
              {copy.nav.contact}
            </Link>
            <Link to="/admin/login" className="hover:text-blue-700 dark:hover:text-blue-400 whitespace-nowrap">
              {language === 'bn' ? 'অ্যাডমিন লগইন' : 'Admin Login'}
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <div className="inline-flex items-center gap-1">
              <button
                type="button"
                onClick={() => setLanguage('bn')}
                className={`px-2 py-0.5 rounded cursor-pointer transition-colors ${
                  language === 'bn'
                    ? 'bg-blue-700 text-white font-medium'
                    : 'hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 rounded cursor-pointer transition-colors ${
                  language === 'en'
                    ? 'bg-blue-700 text-white font-medium'
                    : 'hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                EN
              </button>
            </div>

            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle Color Theme"
              className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
            >
              {theme === 'light' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
              <span>{theme === 'light' ? (language === 'bn' ? 'ডার্ক' : 'Dark') : (language === 'bn' ? 'লাইট' : 'Light')}</span>
            </button>

            {firebaseUser && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setNotifOpen((prev) => !prev)}
                  className="inline-flex items-center gap-1.5 hover:text-blue-700 dark:hover:text-blue-400 cursor-pointer"
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span className="tabular-nums">
                    {language === 'bn' ? `নোটিফিকেশন (${unreadCount})` : `Notifications (${unreadCount})`}
                  </span>
                </button>

                {notifOpen && (
                  <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-lg p-3 z-50">
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200 dark:border-slate-800">
                      <span className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100">
                        {language === 'bn' ? 'নোটিফিকেশন কেন্দ্র' : 'Notification Center'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setNotifOpen(false)}
                        className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                      >
                        {language === 'bn' ? 'বন্ধ' : 'Close'}
                      </button>
                    </div>
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-500 py-4 text-center">
                        {language === 'bn' ? 'কোনো নতুন নোটিফিকেশন নেই' : 'No notifications yet'}
                      </p>
                    ) : (
                      <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                        {notifications.slice(0, 8).map((n) => {
                          const isRead = n.readBy?.includes(firebaseUser.uid);
                          return (
                            <div key={n.id} className="py-2.5 flex items-start justify-between gap-2">
                              <div>
                                <p className={`text-xs font-semibold ${isRead ? 'text-slate-600 dark:text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                                  {n.title}
                                </p>
                                <p className="text-xs text-slate-500 mt-0.5 leading-snug">{n.message}</p>
                              </div>
                              {!isRead && (
                                <button
                                  type="button"
                                  onClick={() => markNotificationRead(n.id, firebaseUser.uid)}
                                  title="পঠিত চিহ্নিত করুন"
                                  className="text-blue-700 dark:text-blue-400 hover:text-blue-900 shrink-0 p-1 cursor-pointer"
                                >
                                  <CheckCheck className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center min-h-[44px] px-3 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900"
            >
              {item.label}
            </NavLink>
          ))}
          <NavLink
            to="/about"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center min-h-[44px] px-3 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900"
          >
            {copy.nav.about}
          </NavLink>
          <NavLink
            to="/contact"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center min-h-[44px] px-3 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900"
          >
            {copy.nav.contact}
          </NavLink>
          <NavLink
            to="/admin/login"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center min-h-[44px] px-3 rounded-lg text-sm font-medium text-blue-700 dark:text-blue-400 hover:bg-slate-50 dark:hover:bg-slate-900"
          >
            {language === 'bn' ? 'অ্যাডমিন পোর্টাল' : 'Admin Portal'}
          </NavLink>

          <div className="pt-3 flex items-center justify-between border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
                className="px-3 py-2 min-h-[40px] text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
              >
                {language === 'bn' ? 'English' : 'বাংলা'}
              </button>
              <button
                type="button"
                onClick={toggleTheme}
                className="px-3 py-2 min-h-[40px] text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
              >
                {theme === 'light' ? 'Dark' : 'Light'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                handlePrimaryAction();
              }}
              className="px-4 py-2 min-h-[44px] text-sm font-semibold text-white bg-blue-700 rounded-lg cursor-pointer"
            >
              {!firebaseUser
                ? copy.actions.login
                : role === 'admin'
                ? copy.actions.adminPanel
                : copy.actions.dashboard}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
