import { useState, FormEvent, ChangeEvent } from 'react';
import { Plus, Trash2, Edit2, Upload, Eye, EyeOff } from 'lucide-react';
import {
  deleteEntity,
  saveEntity,
  uploadHealthcareImage,
} from '../../services/firestoreService';
import {
  AdCategory,
  AdPlacement,
  Advertisement,
  Department,
  DiagnosticCenter,
  Doctor,
  Hospital,
} from '../../types/healthcare';

export function AdminDoctorsPanel({
  doctors,
  departments,
  hospitals,
  onNotify,
}: {
  doctors: Doctor[];
  departments: Department[];
  hospitals: Hospital[];
  onNotify: (msg: string) => void;
}) {
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [degree, setDegree] = useState('');
  const [department, setDepartment] = useState('');
  const [hospitalName, setHospitalName] = useState('');
  const [location, setLocation] = useState('ঢাকা');
  const [visitingSchedule, setVisitingSchedule] = useState('');
  const [consultationFee, setConsultationFee] = useState('1000');
  const [slotsText, setSlotsText] = useState('05:00 PM, 06:00 PM, 07:00 PM');
  const [photoUrl, setPhotoUrl] = useState('');
  const [featured, setFeatured] = useState(true);
  const [active, setActive] = useState(true);
  const [busy, setBusy] = useState(false);

  function loadForEdit(d: Doctor) {
    setEditingId(d.id);
    setName(d.name);
    setDegree(d.degree);
    setDepartment(d.department);
    setHospitalName(d.hospitalName);
    setLocation(d.location);
    setVisitingSchedule(d.visitingSchedule || '');
    setConsultationFee(String(d.consultationFee));
    setSlotsText((d.availableSlots || []).join(', '));
    setPhotoUrl(d.photoUrl || '');
    setFeatured(Boolean(d.featured));
    setActive(d.active);
  }

  function resetForm() {
    setEditingId(null);
    setName('');
    setDegree('');
    setDepartment(departments[0]?.nameBn || '');
    setHospitalName(hospitals[0]?.name || '');
    setLocation('ঢাকা');
    setVisitingSchedule('');
    setConsultationFee('1000');
    setSlotsText('05:00 PM, 06:00 PM, 07:00 PM');
    setPhotoUrl('');
    setFeatured(true);
    setActive(true);
  }

  async function handlePhotoUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const url = await uploadHealthcareImage(file, 'doctors');
      setPhotoUrl(url);
      onNotify('ডাক্তারের ছবি আপলোড হয়েছে।');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await saveEntity(
        'doctors',
        editingId,
        {
          name: name.trim(),
          degree: degree.trim(),
          department: department.trim() || 'মেডিসিন',
          hospitalName: hospitalName.trim() || 'ঢাকা সেন্ট্রাল হাসপাতাল',
          location: location.trim(),
          visitingSchedule: visitingSchedule.trim(),
          consultationFee: Number(consultationFee) || 0,
          availableSlots: slotsText
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean),
          photoUrl: photoUrl.trim(),
          featured,
          active,
          rating: 4.8,
          reviewCount: 0,
        },
        editingId ? 'Edit Doctor' : 'Add Doctor'
      );
      onNotify(editingId ? 'ডাক্তার তথ্য আপডেট হয়েছে।' : 'নতুন ডাক্তার যুক্ত হয়েছে।');
      resetForm();
    } finally {
      setBusy(false);
    }
  }

  const filtered = doctors.filter(
    (d) =>
      !search.trim() ||
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.department.toLowerCase().includes(search.toLowerCase()) ||
      d.hospitalName.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-lg">
            {editingId ? 'ডাক্তার সম্পাদনা করুন' : 'নতুন ডাক্তার যুক্ত করুন'}
          </h3>
          {editingId && (
            <button type="button" onClick={resetForm} className="text-xs text-blue-700 cursor-pointer">
              নতুন ফর্ম
            </button>
          )}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <input
            type="text"
            required
            placeholder="ডাক্তারের পূর্ণ নাম"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <input
            type="text"
            required
            placeholder="ডিগ্রি (যেমন: MBBS, FCPS)"
            value={degree}
            onChange={(e) => setDegree(e.target.value)}
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <input
            type="text"
            required
            placeholder="বিভাগ (যেমন: হৃদরোগ)"
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
            list="dept-options"
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <datalist id="dept-options">
            {departments.map((d) => (
              <option key={d.id} value={d.nameBn} />
            ))}
          </datalist>

          <input
            type="text"
            required
            placeholder="হাসপাতাল / চেম্বারের নাম"
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            list="hosp-options"
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <datalist id="hosp-options">
            {hospitals.map((h) => (
              <option key={h.id} value={h.name} />
            ))}
          </datalist>

          <input
            type="text"
            required
            placeholder="শহর / লোকেশন"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <input
            type="number"
            required
            placeholder="পরামর্শ ফি (৳)"
            value={consultationFee}
            onChange={(e) => setConsultationFee(e.target.value)}
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums"
          />
          <input
            type="text"
            placeholder="ভিজিটিং সময়সূচি (শনি–বুধ বিকাল ৫টা)"
            value={visitingSchedule}
            onChange={(e) => setVisitingSchedule(e.target.value)}
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <input
            type="text"
            placeholder="স্লট (কমা দিয়ে: 05:00 PM, 06:00 PM)"
            value={slotsText}
            onChange={(e) => setSlotsText(e.target.value)}
            className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="ছবির URL বা আপলোড করুন"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              className="flex-1 min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
            />
            <label className="px-3 py-2 min-h-[40px] inline-flex items-center gap-1 text-xs font-medium border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer shrink-0">
              <Upload className="w-3.5 h-3.5" />
              <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
            </label>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-xs">
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
              <span>সক্রিয় (Active)</span>
            </label>
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={featured}
                onChange={(e) => setFeatured(e.target.checked)}
              />
              <span>ফিচার্ড (Homepage)</span>
            </label>
          </div>
          <button
            type="submit"
            disabled={busy}
            className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{editingId ? 'আপডেট সংরক্ষণ' : 'ডাক্তার যুক্ত করুন'}</span>
          </button>
        </div>
      </form>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <h4 className="font-display font-bold text-base">তালিকাভুক্ত ডাক্তার ({filtered.length})</h4>
          <input
            type="text"
            placeholder="ডাক্তার খুঁজুন..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800 text-xs text-slate-500">
              <tr>
                <th className="text-left px-4 py-2.5">নাম ও ডিগ্রি</th>
                <th className="text-left px-4 py-2.5">বিভাগ ও হাসপাতাল</th>
                <th className="text-right px-4 py-2.5">ফি</th>
                <th className="text-left px-4 py-2.5">অবস্থা</th>
                <th className="text-right px-4 py-2.5">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {filtered.map((d) => (
                <tr key={d.id}>
                  <td className="px-4 py-3">
                    <p className="font-semibold">{d.name}</p>
                    <p className="text-xs text-slate-500">{d.degree}</p>
                  </td>
                  <td className="px-4 py-3 text-xs">
                    <p>{d.department}</p>
                    <p className="text-slate-500">{d.hospitalName} · {d.location}</p>
                  </td>
                  <td className="px-4 py-3 text-right font-semibold tabular-nums">
                    ৳ {d.consultationFee}
                  </td>
                  <td className="px-4 py-3 text-xs">
                    {d.active ? 'Active' : 'Inactive'}
                  </td>
                  <td className="px-4 py-3 text-right space-x-2 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => loadForEdit(d)}
                      aria-label="Edit Doctor"
                      className="p-1.5 text-blue-700 hover:bg-blue-50 dark:hover:bg-slate-800 rounded cursor-pointer"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        void saveEntity('doctors', d.id, { active: !d.active }, 'Toggle Doctor Status')
                      }
                      aria-label="Toggle Active"
                      className="p-1.5 text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer"
                    >
                      {d.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`${d.name} ডিলিট করতে চান?`)) {
                          void deleteEntity('doctors', d.id, 'Delete Doctor');
                        }
                      }}
                      aria-label="Delete Doctor"
                      className="p-1.5 text-red-600 hover:bg-red-50 dark:hover:bg-slate-800 rounded cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function AdminHospitalsPanel({
  hospitals,
  onNotify,
}: {
  hospitals: Hospital[];
  onNotify: (msg: string) => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [location, setLocation] = useState('ঢাকা');
  const [contactPhone, setContactPhone] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [departmentsText, setDepartmentsText] = useState('');
  const [facilitiesText, setFacilitiesText] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [published, setPublished] = useState(true);

  function loadEdit(h: Hospital) {
    setEditingId(h.id);
    setName(h.name);
    setAddress(h.address);
    setLocation(h.location);
    setContactPhone(h.contactPhone);
    setEmergencyPhone(h.emergencyPhone || '');
    setDepartmentsText((h.departments || []).join(', '));
    setFacilitiesText((h.medicalFacilities || []).join(', '));
    setImageUrl(h.imageUrl || '');
    setPublished(h.published);
  }

  async function handleImageUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadHealthcareImage(file, 'hospitals');
    setImageUrl(url);
    onNotify('হাসপাতালের ছবি আপলোড হয়েছে।');
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    await saveEntity(
      'hospitals',
      editingId,
      {
        name: name.trim(),
        address: address.trim(),
        location: location.trim(),
        contactPhone: contactPhone.trim(),
        emergencyPhone: emergencyPhone.trim(),
        departments: departmentsText.split(',').map((s) => s.trim()).filter(Boolean),
        medicalFacilities: facilitiesText.split(',').map((s) => s.trim()).filter(Boolean),
        imageUrl: imageUrl.trim(),
        published,
      },
      editingId ? 'Edit Hospital' : 'Add Hospital'
    );
    onNotify('হাসপাতালের তথ্য সংরক্ষিত হয়েছে।');
    setEditingId(null);
    setName('');
    setAddress('');
    setContactPhone('');
    setEmergencyPhone('');
    setDepartmentsText('');
    setFacilitiesText('');
    setImageUrl('');
  }

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
      >
        <h3 className="font-display font-bold text-lg">
          {editingId ? 'হাসপাতাল সম্পাদনা' : 'নতুন হাসপাতাল যুক্ত করুন'}
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <input required placeholder="হাসপাতালের নাম" value={name} onChange={(e) => setName(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input required placeholder="ঠিকানা" value={address} onChange={(e) => setAddress(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input required placeholder="শহর" value={location} onChange={(e) => setLocation(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input required placeholder="যোগাযোগ নম্বর" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input placeholder="জরুরি হটলাইন" value={emergencyPhone} onChange={(e) => setEmergencyPhone(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input placeholder="বিভাগসমূহ (কমা দিয়ে)" value={departmentsText} onChange={(e) => setDepartmentsText(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input placeholder="সুবিধাসমূহ (ICU, Ambulance)" value={facilitiesText} onChange={(e) => setFacilitiesText(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <div className="flex items-center gap-2">
            <input placeholder="ছবির URL" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="flex-1 min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
            <label className="px-3 py-2 min-h-[40px] inline-flex items-center border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            </label>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <label className="inline-flex items-center gap-1.5 text-xs cursor-pointer">
            <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} />
            <span>প্রকাশিত (Published)</span>
          </label>
          <button type="submit" className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer">
            {editingId ? 'আপডেট করুন' : 'হাসপাতাল যুক্ত করুন'}
          </button>
        </div>
      </form>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
        {hospitals.map((h) => (
          <div key={h.id} className="p-4 flex items-center justify-between gap-4">
            <div>
              <p className="font-semibold text-sm">{h.name}</p>
              <p className="text-xs text-slate-500">{h.location} · {h.contactPhone} · {h.published ? 'Published' : 'Hidden'}</p>
            </div>
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => loadEdit(h)} className="p-1.5 text-blue-700 cursor-pointer"><Edit2 className="w-4 h-4" /></button>
              <button
                type="button"
                onClick={() => void saveEntity('hospitals', h.id, { published: !h.published }, 'Toggle Hospital Publish')}
                className="p-1.5 text-slate-600 cursor-pointer"
              >
                {h.published ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`${h.name} ডিলিট করতে চান?`)) {
                    void deleteEntity('hospitals', h.id, 'Delete Hospital');
                  }
                }}
                className="p-1.5 text-red-600 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AdminDiagnosticsPanel({
  centers,
  onNotify,
}: {
  centers: DiagnosticCenter[];
  onNotify: (msg: string) => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [location, setLocation] = useState('ঢাকা');
  const [contactPhone, setContactPhone] = useState('');
  const [openingHours, setOpeningHours] = useState('সকাল ৭:০০ – রাত ১১:০০');
  const [testsText, setTestsText] = useState('CBC:450, HbA1c:950, X-Ray:600');
  const [imageUrl, setImageUrl] = useState('');

  async function handleImageUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadHealthcareImage(file, 'diagnostics');
    setImageUrl(url);
    onNotify('ডায়াগনস্টিক সেন্টারের ছবি আপলোড হয়েছে।');
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const availableTests = testsText
      .split(',')
      .map((pair) => {
        const [tName, tPrice] = pair.split(':');
        return { name: (tName || '').trim(), price: Number(tPrice) || 0 };
      })
      .filter((t) => t.name.length > 0);

    await saveEntity(
      'diagnostic_centers',
      editingId,
      {
        name: name.trim(),
        address: address.trim(),
        location: location.trim(),
        contactPhone: contactPhone.trim(),
        openingHours: openingHours.trim(),
        availableTests,
        imageUrl: imageUrl.trim(),
        published: true,
      },
      editingId ? 'Edit Diagnostic Center' : 'Add Diagnostic Center'
    );
    onNotify('ডায়াগনস্টিক সেন্টার সংরক্ষিত হয়েছে।');
    setEditingId(null);
    setName('');
    setAddress('');
    setContactPhone('');
  }

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
      >
        <h3 className="font-display font-bold text-lg">
          {editingId ? 'ডায়াগনস্টিক সেন্টার সম্পাদনা' : 'নতুন ডায়াগনস্টিক সেন্টার যুক্ত করুন'}
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <input required placeholder="সেন্টারের নাম" value={name} onChange={(e) => setName(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input required placeholder="ঠিকানা" value={address} onChange={(e) => setAddress(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input required placeholder="শহর" value={location} onChange={(e) => setLocation(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input required placeholder="ফোন নম্বর" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input placeholder="খোলার সময়" value={openingHours} onChange={(e) => setOpeningHours(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <div className="flex items-center gap-2">
            <input placeholder="ছবির URL" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="flex-1 min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
            <label className="px-3 py-2 min-h-[40px] inline-flex items-center border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            </label>
          </div>
          <input
            placeholder="টেস্ট ও মূল্য (নাম:মূল্য কমা দিয়ে)"
            value={testsText}
            onChange={(e) => setTestsText(e.target.value)}
            className="sm:col-span-2 lg:col-span-3 min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
        </div>
        <button type="submit" className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer">
          {editingId ? 'আপডেট করুন' : 'সেন্টার যুক্ত করুন'}
        </button>
      </form>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
        {centers.map((c) => (
          <div key={c.id} className="p-4 flex items-center justify-between gap-4">
            <div>
              <p className="font-semibold text-sm">{c.name}</p>
              <p className="text-xs text-slate-500">
                {c.location} · {c.contactPhone} · {(c.availableTests || []).length} tests
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setEditingId(c.id);
                  setName(c.name);
                  setAddress(c.address);
                  setLocation(c.location);
                  setContactPhone(c.contactPhone);
                  setOpeningHours(c.openingHours || '');
                  setImageUrl(c.imageUrl || '');
                  setTestsText(
                    (c.availableTests || []).map((t) => `${t.name}:${t.price}`).join(', ')
                  );
                }}
                className="p-1.5 text-blue-700 cursor-pointer"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`${c.name} ডিলিট করতে চান?`)) {
                    void deleteEntity('diagnostic_centers', c.id, 'Delete Diagnostic Center');
                  }
                }}
                className="p-1.5 text-red-600 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AdminAdsPanel({
  advertisements,
  onNotify,
}: {
  advertisements: Advertisement[];
  onNotify: (msg: string) => void;
}) {
  const today = new Date().toISOString().split('T')[0];
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<AdCategory>('hospital');
  const [placement, setPlacement] = useState<AdPlacement>('home_top');
  const [imageUrl, setImageUrl] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [whatsappUrl, setWhatsappUrl] = useState('');
  const [startDate, setStartDate] = useState(today);
  const [expiryDate, setExpiryDate] = useState('2027-12-31');
  const [priority, setPriority] = useState('10');
  const [active, setActive] = useState(true);

  async function handleBannerUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadHealthcareImage(file, 'advertisements');
    setImageUrl(url);
    onNotify('বিজ্ঞাপনের ব্যানার আপলোড হয়েছে।');
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    await saveEntity(
      'advertisements',
      editingId,
      {
        title: title.trim(),
        description: description.trim(),
        category,
        placement,
        imageUrl: imageUrl.trim(),
        contactNumber: contactNumber.trim(),
        websiteUrl: websiteUrl.trim(),
        whatsappUrl: whatsappUrl.trim(),
        startDate,
        expiryDate,
        active,
        priority: Number(priority) || 1,
        impressions: 0,
        clicks: 0,
      },
      editingId ? 'Edit Advertisement' : 'Create Advertisement'
    );
    onNotify('বিজ্ঞাপন সংরক্ষিত হয়েছে — ওয়েবসাইটে তাৎক্ষণিকভাবে কার্যকর হবে।');
    setEditingId(null);
    setTitle('');
    setDescription('');
    setImageUrl('');
  }

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4"
      >
        <h3 className="font-display font-bold text-lg">
          {editingId ? 'বিজ্ঞাপন সম্পাদনা' : 'নতুন ডায়নামিক বিজ্ঞাপন / ব্যানার যুক্ত করুন'}
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <input required placeholder="বিজ্ঞাপনের শিরোনাম" value={title} onChange={(e) => setTitle(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <select value={category} onChange={(e) => setCategory(e.target.value as AdCategory)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg">
            <option value="hospital">Hospital Advertisement</option>
            <option value="diagnostic">Diagnostic Center Ad</option>
            <option value="doctor">Doctor Advertisement</option>
            <option value="sponsored">Sponsored Promotion</option>
            <option value="service">Medical Service Promotion</option>
          </select>
          <select value={placement} onChange={(e) => setPlacement(e.target.value as AdPlacement)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg">
            <option value="home_top">Homepage Top Banner</option>
            <option value="home_middle">Homepage Middle Banner</option>
            <option value="home_bottom">Homepage Bottom Banner</option>
            <option value="doctor_banner">Doctor Directory Banner</option>
            <option value="hospital_banner">Hospital Directory Banner</option>
            <option value="diagnostic_banner">Diagnostic Center Banner</option>
            <option value="fullscreen_promo">Full-Screen Promotional Banner</option>
          </select>
          <input placeholder="যোগাযোগ নম্বর" value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input placeholder="ওয়েবসাইট লিংক (/hospitals বা https://...)" value={websiteUrl} onChange={(e) => setWebsiteUrl(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input placeholder="WhatsApp লিংক (https://wa.me/...)" value={whatsappUrl} onChange={(e) => setWhatsappUrl(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums" />
          <input type="date" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums" />
          <input type="number" placeholder="অগ্রাধিকার (Priority)" value={priority} onChange={(e) => setPriority(e.target.value)} className="min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg tabular-nums" />
          <div className="sm:col-span-2 lg:col-span-3 flex items-center gap-2">
            <input placeholder="ব্যানার ছবির URL বা ফাইল আপলোড করুন" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="flex-1 min-h-[40px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg" />
            <label className="px-3 py-2 min-h-[40px] inline-flex items-center gap-1.5 text-xs border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>ব্যানার আপলোড</span>
              <input type="file" accept="image/*" className="hidden" onChange={handleBannerUpload} />
            </label>
          </div>
          <textarea
            rows={2}
            placeholder="বিজ্ঞাপনের বিবরণ"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="sm:col-span-2 lg:col-span-3 px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg"
          />
        </div>
        <div className="flex items-center justify-between">
          <label className="inline-flex items-center gap-1.5 text-xs cursor-pointer">
            <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
            <span>সক্রিয় (Active)</span>
          </label>
          <button type="submit" className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer">
            {editingId ? 'বিজ্ঞাপন আপডেট করুন' : 'বিজ্ঞাপন প্রকাশ করুন'}
          </button>
        </div>
      </form>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
        {advertisements.map((ad) => {
          const isExpired = ad.expiryDate < today;
          return (
            <div key={ad.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-sm">{ad.title}</p>
                <p className="text-xs text-slate-500 tabular-nums">
                  {ad.placement} · Priority {ad.priority} · {ad.startDate} to {ad.expiryDate} · Clicks: {ad.clicks || 0} ·{' '}
                  {isExpired ? 'Expired (Auto-hidden)' : ad.active ? 'Active' : 'Paused'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(ad.id);
                    setTitle(ad.title);
                    setDescription(ad.description || '');
                    setCategory(ad.category);
                    setPlacement(ad.placement);
                    setImageUrl(ad.imageUrl || '');
                    setContactNumber(ad.contactNumber || '');
                    setWebsiteUrl(ad.websiteUrl || '');
                    setWhatsappUrl(ad.whatsappUrl || '');
                    setStartDate(ad.startDate);
                    setExpiryDate(ad.expiryDate);
                    setPriority(String(ad.priority));
                    setActive(ad.active);
                  }}
                  className="p-1.5 text-blue-700 cursor-pointer"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    void saveEntity('advertisements', ad.id, { active: !ad.active }, 'Toggle Ad Status')
                  }
                  className="p-1.5 text-slate-600 cursor-pointer"
                >
                  {ad.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(`"${ad.title}" ডিলিট করতে চান?`)) {
                      void deleteEntity('advertisements', ad.id, 'Delete Advertisement');
                    }
                  }}
                  className="p-1.5 text-red-600 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
