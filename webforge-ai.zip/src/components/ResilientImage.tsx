import { useState } from 'react';
import { Building2 } from 'lucide-react';

interface ResilientImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export function ResilientImage({
  src,
  alt,
  className = '',
  fallbackTitle,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (!src || hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-blue-50 dark:bg-slate-900 text-blue-900 dark:text-slate-200 border border-slate-200 dark:border-slate-800 p-6 text-center ${className}`}
      >
        <Building2 className="w-7 h-7 mb-2 text-blue-700 dark:text-blue-400" strokeWidth={1.5} />
        <p className="text-xs sm:text-sm font-medium line-clamp-2">
          {fallbackTitle || alt}
        </p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
