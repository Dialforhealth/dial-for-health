import { X, ArrowRight } from 'lucide-react';
import { CaseStudy } from '../data/studioData';
import { ResilientImage } from './ResilientImage';

interface CaseStudyModalProps {
  study: CaseStudy | null;
  onClose: () => void;
  onRequestSimilar: (study: CaseStudy) => void;
}

export function CaseStudyModal({
  study,
  onClose,
  onRequestSimilar,
}: CaseStudyModalProps) {
  if (!study) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="case-study-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white border border-slate-200 rounded-xl shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 p-6 border-b border-slate-200">
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">
              {study.category} <span aria-hidden="true">·</span> {study.year} <span aria-hidden="true">·</span> {study.location}
            </p>
            <h3
              id="case-study-modal-title"
              className="font-display text-2xl font-bold text-slate-900"
            >
              {study.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="বিস্তারিত বন্ধ করুন"
            className="inline-flex items-center justify-center w-10 h-10 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300 cursor-pointer shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="aspect-[16/9] rounded-lg overflow-hidden border border-slate-200">
            <ResilientImage
              src={study.image}
              alt={study.imageAlt}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
            <p className="text-xs text-slate-500 mb-1">পরিমাপযোগ্য ফলাফল</p>
            <p className="font-display text-xl font-bold text-blue-800 tabular-nums">
              {study.metric}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <h4 className="font-display font-semibold text-base text-slate-900 mb-2">
                পূর্বের সমস্যা
              </h4>
              <p className="text-sm text-slate-600 leading-relaxed">{study.challenge}</p>
            </div>
            <div>
              <h4 className="font-display font-semibold text-base text-slate-900 mb-2">
                আমাদের সমাধান
              </h4>
              <p className="text-sm text-slate-600 leading-relaxed">{study.solution}</p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200">
            <p className="text-xs text-slate-500 mb-2">সম্পন্ন কাজসমূহ</p>
            <p className="text-sm font-medium text-slate-800">
              {study.deliverables.join(' · ')}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 p-6 bg-slate-50 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 min-h-[40px] text-sm font-medium text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            বন্ধ করুন
          </button>
          <button
            type="button"
            onClick={() => onRequestSimilar(study)}
            className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-800 hover:bg-blue-900 rounded-lg transition-colors cursor-pointer"
          >
            <span>এই ধরনের ওয়েবসাইট অর্ডার করুন</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
