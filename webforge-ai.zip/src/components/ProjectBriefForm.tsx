import { useState, useEffect, FormEvent } from 'react';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import {
  BLUEPRINT_CONFIGS,
  BlueprintCategory,
  BlueprintTone,
} from '../data/studioData';

interface ProjectBriefFormProps {
  initialCategory: BlueprintCategory;
  initialTone: BlueprintTone;
  prefillNote?: string;
}

const BUDGET_OPTIONS = [
  { id: 'starter', label: '৳ ১৫,০০০ – ২৫,০০০ (স্টার্টার ও পোর্টফোলিও)' },
  { id: 'growth', label: '৳ ৩০,০০০ – ৫০,০০০ (ব্যবসা ও ই-কমার্স)' },
  { id: 'custom', label: '৳ ৬০,০০০+ (কাস্টম ওয়েব অ্যাপ)' },
];

const TONE_LABELS: Record<BlueprintTone, string> = {
  clean: 'হালকা ও পরিচ্ছন্ন',
  slate: 'গভীর স্লেট',
  editorial: 'ক্লাসিক প্রিন্ট',
};

export function ProjectBriefForm({
  initialCategory,
  initialTone,
  prefillNote = '',
}: ProjectBriefFormProps) {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [category, setCategory] = useState<BlueprintCategory>(initialCategory);
  const [tone, setTone] = useState<BlueprintTone>(initialTone);
  const [budget, setBudget] = useState('growth');
  const [details, setDetails] = useState(prefillNote);
  const [error, setError] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<{
    name: string;
    contact: string;
    categoryLabel: string;
    toneLabel: string;
    budgetLabel: string;
    details: string;
  } | null>(null);

  useEffect(() => {
    setCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    setTone(initialTone);
  }, [initialTone]);

  useEffect(() => {
    if (prefillNote) {
      setDetails(prefillNote);
    }
  }, [prefillNote]);

  function validateContact(value: string): boolean {
    const trimmed = value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[+]?[\d\s-]{8,16}$/;
    return emailRegex.test(trimmed) || phoneRegex.test(trimmed);
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (name.trim().length < 2) {
      setError('অনুগ্রহ করে আপনার পূর্ণ নাম লিখুন।');
      return;
    }

    if (!validateContact(contact)) {
      setError('অনুগ্রহ করে একটি সঠিক ইমেইল ঠিকানা বা মোবাইল নম্বর দিন।');
      return;
    }

    if (details.trim().length < 10) {
      setError('আপনার ওয়েবসাইটে কী কী পেজ বা সুবিধা চান তা সংক্ষেপে লিখুন (কমপক্ষে ১০ অক্ষর)।');
      return;
    }

    const categoryLabel =
      BLUEPRINT_CONFIGS.find((c) => c.id === category)?.label || 'ব্যবসায়িক ওয়েবসাইট';
    const budgetLabel =
      BUDGET_OPTIONS.find((b) => b.id === budget)?.label || BUDGET_OPTIONS[1].label;

    setSubmittedData({
      name: name.trim(),
      contact: contact.trim(),
      categoryLabel,
      toneLabel: TONE_LABELS[tone],
      budgetLabel,
      details: details.trim(),
    });
  }

  if (submittedData) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="flex items-start gap-3 mb-5">
          <CheckCircle2 className="w-6 h-6 text-emerald-700 shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-2xl font-bold text-slate-900">
              আপনার প্রজেক্ট ব্রিফ সংরক্ষিত হয়েছে
            </h3>
            <p className="text-sm text-slate-600 mt-1">
              ধন্যবাদ, {submittedData.name}। আমাদের ডিজাইন টিম ২৪ ঘণ্টার মধ্যে আপনার দেওয়া নম্বরে বা ইমেইলে প্রাথমিক খসড়া ও সময়সূচি পাঠাবে।
            </p>
          </div>
        </div>

        <dl className="divide-y divide-slate-200 border border-slate-200 rounded-lg bg-slate-50 text-sm mb-6">
          <div className="flex flex-col sm:flex-row sm:justify-between gap-1 px-4 py-3">
            <dt className="text-slate-500">যোগাযোগ মাধ্যম</dt>
            <dd className="font-medium text-slate-900 tabular-nums">{submittedData.contact}</dd>
          </div>
          <div className="flex flex-col sm:flex-row sm:justify-between gap-1 px-4 py-3">
            <dt className="text-slate-500">ওয়েবসাইটের ধরন</dt>
            <dd className="font-medium text-slate-900">{submittedData.categoryLabel}</dd>
          </div>
          <div className="flex flex-col sm:flex-row sm:justify-between gap-1 px-4 py-3">
            <dt className="text-slate-500">পছন্দের স্টাইল</dt>
            <dd className="font-medium text-slate-900">{submittedData.toneLabel}</dd>
          </div>
          <div className="flex flex-col sm:flex-row sm:justify-between gap-1 px-4 py-3">
            <dt className="text-slate-500">বাজেট পরিসীমা</dt>
            <dd className="font-medium text-slate-900 tabular-nums">{submittedData.budgetLabel}</dd>
          </div>
          <div className="px-4 py-3">
            <dt className="text-slate-500 mb-1">প্রজেক্ট বিবরণ</dt>
            <dd className="text-slate-800 leading-relaxed">{submittedData.details}</dd>
          </div>
        </dl>

        <button
          type="button"
          onClick={() => setSubmittedData(null)}
          className="px-4 py-2.5 min-h-[40px] text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:border-slate-400 rounded-lg transition-colors cursor-pointer"
        >
          তথ্য পরিবর্তন করুন বা নতুন রিকোয়েস্ট পাঠান
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-5"
    >
      <div>
        <h3 className="font-display text-2xl font-bold text-slate-900 mb-1">
          আপনার ওয়েবসাইটের বিবরণ দিন
        </h3>
        <p className="text-sm text-slate-600">
          নিচের তথ্যগুলো পূরণ করলে আমরা আপনার প্রয়োজন অনুযায়ী ডিজাইন প্রস্তাবনা ও সময়সীমা তৈরি করে দেব।
        </p>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-start gap-2.5 p-3.5 rounded-lg bg-red-50 border border-red-200 text-red-800 text-sm"
        >
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="brief-name"
            className="block text-sm font-medium text-slate-800 mb-1.5"
          >
            আপনার নাম
          </label>
          <input
            id="brief-name"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="যেমন: মাহফুজুর রহমান"
            className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-blue-800"
          />
        </div>
        <div>
          <label
            htmlFor="brief-contact"
            className="block text-sm font-medium text-slate-800 mb-1.5"
          >
            ইমেইল বা মোবাইল নম্বর
          </label>
          <input
            id="brief-contact"
            type="text"
            required
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            placeholder="name@company.com বা +88017..."
            className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-blue-800"
          />
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="brief-category"
            className="block text-sm font-medium text-slate-800 mb-1.5"
          >
            ওয়েবসাইটের ধরন
          </label>
          <select
            id="brief-category"
            value={category}
            onChange={(e) => setCategory(e.target.value as BlueprintCategory)}
            className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-blue-800"
          >
            {BLUEPRINT_CONFIGS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label
            htmlFor="brief-tone"
            className="block text-sm font-medium text-slate-800 mb-1.5"
          >
            পছন্দের ভিজ্যুয়াল স্টাইল
          </label>
          <select
            id="brief-tone"
            value={tone}
            onChange={(e) => setTone(e.target.value as BlueprintTone)}
            className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-blue-800"
          >
            <option value="clean">হালকা ও পরিচ্ছন্ন</option>
            <option value="slate">গভীর স্লেট</option>
            <option value="editorial">ক্লাসিক প্রিন্ট</option>
          </select>
        </div>
      </div>

      <div>
        <span className="block text-sm font-medium text-slate-800 mb-2">
          আনুমানিক বাজেট পরিসীমা
        </span>
        <div className="grid sm:grid-cols-3 gap-2">
          {BUDGET_OPTIONS.map((option) => {
            const active = budget === option.id;
            return (
              <button
                key={option.id}
                type="button"
                onClick={() => setBudget(option.id)}
                className={`px-3 py-2.5 min-h-[44px] text-xs font-medium text-left rounded-lg border transition-colors cursor-pointer tabular-nums ${
                  active
                    ? 'border-blue-800 bg-blue-50 text-blue-900'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                }`}
              >
                {option.label}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <label
          htmlFor="brief-details"
          className="block text-sm font-medium text-slate-800 mb-1.5"
        >
          কী ধরনের ওয়েবসাইট ও কী কী ফিচার প্রয়োজন?
        </label>
        <textarea
          id="brief-details"
          rows={4}
          required
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          placeholder="উদাহরণ: আমার পোশাকের ব্যবসার জন্য একটি ই-কমার্স ওয়েবসাইট চাই, যেখানে প্রোডাক্ট ফিল্টার, সাইজ চার্ট ও বিকাশ পেমেন্ট থাকবে..."
          className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-blue-800"
        />
      </div>

      <button
        type="submit"
        className="w-full min-h-[46px] px-6 py-3 text-sm font-semibold text-white bg-blue-800 hover:bg-blue-900 rounded-lg transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-800"
      >
        বিনামূল্যে ডিজাইন প্রস্তাবনা চান
      </button>
    </form>
  );
}
