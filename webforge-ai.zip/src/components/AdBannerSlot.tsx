import { useEffect, useState } from 'react';
import { ExternalLink, MessageCircle, PhoneCall, ChevronLeft, ChevronRight } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { trackAdvertisementClick } from '../services/firestoreService';
import { AdPlacement } from '../types/healthcare';
import { ResilientImage } from './ResilientImage';

interface AdBannerSlotProps {
  placement: AdPlacement;
}

export function AdBannerSlot({ placement }: AdBannerSlotProps) {
  const { advertisements, language } = useData();
  const [activeIndex, setActiveIndex] = useState(0);
  const today = new Date().toISOString().split('T')[0];

  const eligibleAds = advertisements
    .filter(
      (ad) =>
        ad.active &&
        ad.placement === placement &&
        (!ad.startDate || ad.startDate <= today) &&
        (!ad.expiryDate || ad.expiryDate >= today)
    )
    .sort((a, b) => (b.priority || 0) - (a.priority || 0));

  useEffect(() => {
    if (eligibleAds.length <= 1) return;
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % eligibleAds.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [eligibleAds.length]);

  if (eligibleAds.length === 0) return null;

  const ad = eligibleAds[activeIndex % eligibleAds.length];
  const isBn = language === 'bn';

  return (
    <aside
      aria-label={isBn ? 'প্রচারণামূলক বিজ্ঞাপন' : 'Sponsored Healthcare Promotion'}
      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
    >
      <div className="grid md:grid-cols-12 items-stretch">
        {ad.imageUrl && (
          <div className="md:col-span-5 min-h-[180px] bg-slate-100 dark:bg-slate-800">
            <ResilientImage
              src={ad.imageUrl}
              alt={ad.title}
              className="w-full h-full object-cover max-h-60"
            />
          </div>
        )}
        <div className={`${ad.imageUrl ? 'md:col-span-7' : 'md:col-span-12'} p-5 sm:p-6 flex flex-col justify-between`}>
          <div>
            <div className="flex items-center justify-between gap-4 mb-2">
              <span className="text-xs font-medium text-blue-700 dark:text-blue-400">
                {isBn ? 'স্পন্সরড হেলথকেয়ার' : 'Sponsored Healthcare'} · {ad.category}
              </span>
              {eligibleAds.length > 1 && (
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    aria-label="Previous Advertisement"
                    onClick={() =>
                      setActiveIndex((prev) => (prev - 1 + eligibleAds.length) % eligibleAds.length)
                    }
                    className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Next Advertisement"
                    onClick={() => setActiveIndex((prev) => (prev + 1) % eligibleAds.length)}
                    className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
            <h3 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100 mb-1.5">
              {ad.title}
            </h3>
            {ad.description && (
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                {ad.description}
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {ad.websiteUrl && (
              <a
                href={ad.websiteUrl}
                onClick={() => void trackAdvertisementClick(ad.id)}
                className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
              >
                <span>{isBn ? 'বিস্তারিত দেখুন' : 'Learn More'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
            {ad.contactNumber && (
              <a
                href={`tel:${ad.contactNumber}`}
                onClick={() => void trackAdvertisementClick(ad.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors tabular-nums"
              >
                <PhoneCall className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                <span>{ad.contactNumber}</span>
              </a>
            )}
            {ad.whatsappUrl && (
              <a
                href={ad.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => void trackAdvertisementClick(ad.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs sm:text-sm font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 rounded-lg transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}
