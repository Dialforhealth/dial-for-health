import { useState } from 'react';
import { Monitor, Smartphone, ArrowRight, Check } from 'lucide-react';
import {
  BLUEPRINT_CONFIGS,
  BlueprintCategory,
  BlueprintTone,
} from '../data/studioData';
import { ResilientImage } from './ResilientImage';

interface BlueprintExplorerProps {
  selectedCategory: BlueprintCategory;
  selectedTone: BlueprintTone;
  onSelectCategory: (category: BlueprintCategory) => void;
  onSelectTone: (tone: BlueprintTone) => void;
  onApplyBlueprint: (category: BlueprintCategory, tone: BlueprintTone) => void;
}

const TONE_OPTIONS: Array<{
  id: BlueprintTone;
  label: string;
  swatchClass: string;
}> = [
  { id: 'clean', label: 'হালকা ও পরিচ্ছন্ন', swatchClass: 'bg-white border-slate-300' },
  { id: 'slate', label: 'গভীর স্লেট', swatchClass: 'bg-slate-900 border-slate-700' },
  { id: 'editorial', label: 'ক্লাসিক প্রিন্ট', swatchClass: 'bg-stone-100 border-stone-300' },
];

export function BlueprintExplorer({
  selectedCategory,
  selectedTone,
  onSelectCategory,
  onSelectTone,
  onApplyBlueprint,
}: BlueprintExplorerProps) {
  const [viewportMode, setViewportMode] = useState<'desktop' | 'mobile'>('desktop');
  const [activePreviewTab, setActivePreviewTab] = useState<'home' | 'highlights' | 'contact'>('home');
  const [previewInquirySent, setPreviewInquirySent] = useState(false);

  const activeConfig =
    BLUEPRINT_CONFIGS.find((c) => c.id === selectedCategory) ?? BLUEPRINT_CONFIGS[0];

  const toneStyles = {
    clean: {
      canvas: 'bg-white text-slate-900',
      header: 'bg-white border-slate-200',
      muted: 'text-slate-600',
      card: 'bg-slate-50 border-slate-200',
      button: 'bg-blue-800 text-white hover:bg-blue-900',
      accentText: 'text-blue-800',
    },
    slate: {
      canvas: 'bg-slate-950 text-slate-100',
      header: 'bg-slate-950 border-slate-800',
      muted: 'text-slate-300',
      card: 'bg-slate-900 border-slate-800',
      button: 'bg-blue-600 text-white hover:bg-blue-500',
      accentText: 'text-blue-400',
    },
    editorial: {
      canvas: 'bg-[#F6F5F1] text-stone-900',
      header: 'bg-[#F6F5F1] border-stone-200',
      muted: 'text-stone-600',
      card: 'bg-white border-stone-200',
      button: 'bg-stone-900 text-white hover:bg-stone-800',
      accentText: 'text-stone-900',
    },
  }[selectedTone];

  return (
    <section id="blueprint" className="py-16 sm:py-24 border-t border-slate-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-blue-800 mb-2">
              ডিজাইন স্টুডিও ও লাইভ প্রিভিউ
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 [text-wrap:balance]">
              আপনার ওয়েবসাইটটি দেখতে কেমন হতে পারে, এখনি যাচাই করুন
            </h2>
          </div>
          <p className="text-base text-slate-600 max-w-md leading-relaxed">
            ক্যাটাগরি ও কালার টোন পরিবর্তন করে লাইভ লেআউট পরীক্ষা করুন। পছন্দ হলে একটি ক্লিকেই প্রজেক্ট ব্রিফে যুক্ত করতে পারবেন।
          </p>
        </div>

        {/* Interactive Controls Bar */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl mb-8">
          {/* Category Segmented Controls */}
          <div
            role="tablist"
            aria-label="ওয়েবসাইটের ধরন নির্বাচন"
            className="flex flex-wrap items-center gap-1.5"
          >
            {BLUEPRINT_CONFIGS.map((item) => {
              const isSelected = item.id === selectedCategory;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => {
                    onSelectCategory(item.id);
                    setActivePreviewTab('home');
                    setPreviewInquirySent(false);
                  }}
                  className={`px-3.5 py-2 min-h-[40px] text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-800 ${
                    isSelected
                      ? 'bg-slate-900 text-white'
                      : 'bg-white text-slate-700 border border-slate-200 hover:border-slate-300 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-4 justify-between xl:justify-end">
            {/* Tone Selector */}
            <div className="flex items-center gap-1.5" role="group" aria-label="ভিজ্যুয়াল টোন">
              {TONE_OPTIONS.map((tone) => {
                const isSelected = tone.id === selectedTone;
                return (
                  <button
                    key={tone.id}
                    type="button"
                    onClick={() => onSelectTone(tone.id)}
                    className={`inline-flex items-center gap-2 px-3 py-2 min-h-[40px] text-xs font-medium rounded-lg border transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-800 ${
                      isSelected
                        ? 'border-blue-800 bg-blue-50 text-blue-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <span
                      aria-hidden="true"
                      className={`w-3 h-3 rounded-full border ${tone.swatchClass}`}
                    />
                    {tone.label}
                  </button>
                );
              })}
            </div>

            {/* Viewport Switcher */}
            <div className="inline-flex items-center p-1 bg-white border border-slate-200 rounded-lg">
              <button
                type="button"
                onClick={() => setViewportMode('desktop')}
                aria-label="ডেস্কটপ প্রিভিউ"
                aria-pressed={viewportMode === 'desktop'}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  viewportMode === 'desktop'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>ডেস্কটপ</span>
              </button>
              <button
                type="button"
                onClick={() => setViewportMode('mobile')}
                aria-label="মোবাইল প্রিভিউ"
                aria-pressed={viewportMode === 'mobile'}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  viewportMode === 'mobile'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>মোবাইল</span>
              </button>
            </div>
          </div>
        </div>

        {/* Live Simulated Browser Frame */}
        <div className="flex justify-center">
          <div
            className={`w-full transition-all duration-200 border border-slate-200 rounded-xl overflow-hidden shadow-sm ${
              viewportMode === 'mobile' ? 'max-w-[390px]' : 'max-w-full'
            }`}
          >
            {/* Minimal Browser Top Chrome */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-100 border-b border-slate-200">
              <div className="flex items-center gap-1.5" aria-hidden="true">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
              </div>
              <span className="font-mono-tabular text-xs text-slate-500 truncate px-3">
                {activeConfig.brandSample} · প্রিভিউ
              </span>
              <span className="text-xs font-medium text-slate-500 whitespace-nowrap">
                {viewportMode === 'desktop' ? '১৪৪০px' : '৩৯০px'}
              </span>
            </div>

            {/* Simulated Website Interior */}
            <div className={`${toneStyles.canvas} transition-colors duration-200`}>
              {/* Mini Top Bar */}
              <div
                className={`flex items-center justify-between gap-4 px-5 sm:px-8 py-4 border-b ${toneStyles.header}`}
              >
                <span className="font-display font-bold text-base tracking-tight whitespace-nowrap shrink-0">
                  {activeConfig.brandSample}
                </span>

                <div className="flex items-center gap-4 sm:gap-6 text-xs sm:text-sm font-medium overflow-x-auto">
                  <button
                    type="button"
                    onClick={() => setActivePreviewTab('home')}
                    className={`whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 transition-colors ${
                      activePreviewTab === 'home'
                        ? 'border-current font-semibold'
                        : `border-transparent ${toneStyles.muted}`
                    }`}
                  >
                    {activeConfig.navItems[0]}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActivePreviewTab('highlights')}
                    className={`whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 transition-colors ${
                      activePreviewTab === 'highlights'
                        ? 'border-current font-semibold'
                        : `border-transparent ${toneStyles.muted}`
                    }`}
                  >
                    {activeConfig.navItems[1]}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActivePreviewTab('contact')}
                    className={`whitespace-nowrap shrink-0 cursor-pointer pb-0.5 border-b-2 transition-colors ${
                      activePreviewTab === 'contact'
                        ? 'border-current font-semibold'
                        : `border-transparent ${toneStyles.muted}`
                    }`}
                  >
                    {activeConfig.navItems[2]}
                  </button>
                </div>
              </div>

              {/* Mini Website Body Content */}
              <div className="p-5 sm:p-8 lg:p-10">
                {activePreviewTab === 'home' && (
                  <div
                    className={`grid gap-8 items-stretch ${
                      viewportMode === 'desktop' ? 'lg:grid-cols-12' : 'grid-cols-1'
                    }`}
                  >
                    <div
                      className={`flex flex-col justify-center ${
                        viewportMode === 'desktop' ? 'lg:col-span-7' : ''
                      }`}
                    >
                      <p className={`text-xs font-medium mb-2 ${toneStyles.accentText}`}>
                        {activeConfig.label}
                      </p>
                      <h3 className="font-display text-2xl sm:text-3xl font-bold leading-snug mb-3 [text-wrap:balance]">
                        {activeConfig.headline}
                      </h3>
                      <p className={`text-sm sm:text-base leading-relaxed mb-6 ${toneStyles.muted}`}>
                        {activeConfig.subheadline}
                      </p>
                      <div className="flex flex-wrap items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setActivePreviewTab('highlights')}
                          className={`px-4 py-2.5 text-sm font-semibold rounded-lg transition-colors cursor-pointer ${toneStyles.button}`}
                        >
                          {activeConfig.ctaLabel}
                        </button>
                        <button
                          type="button"
                          onClick={() => setActivePreviewTab('contact')}
                          className={`px-4 py-2.5 text-sm font-medium underline underline-offset-4 cursor-pointer ${toneStyles.muted}`}
                        >
                          যোগাযোগ করুন
                        </button>
                      </div>
                    </div>
                    <div
                      className={`${
                        viewportMode === 'desktop' ? 'lg:col-span-5' : ''
                      } min-h-[220px] rounded-lg overflow-hidden border border-slate-200/40`}
                    >
                      <ResilientImage
                        src={activeConfig.image}
                        alt={activeConfig.imageAlt}
                        className="w-full h-full object-cover min-h-[220px]"
                      />
                    </div>
                  </div>
                )}

                {activePreviewTab === 'highlights' && (
                  <div>
                    <div className="flex items-center justify-between gap-4 mb-6">
                      <h3 className="font-display text-xl sm:text-2xl font-bold">
                        {activeConfig.navItems[1]} ও মূল বৈশিষ্ট্য
                      </h3>
                      <button
                        type="button"
                        onClick={() => setActivePreviewTab('home')}
                        className={`text-xs font-medium underline underline-offset-4 cursor-pointer ${toneStyles.muted}`}
                      >
                        মূল পাতায় ফিরুন
                      </button>
                    </div>
                    <div
                      className={`grid gap-4 ${
                        viewportMode === 'desktop' ? 'md:grid-cols-3' : 'grid-cols-1'
                      }`}
                    >
                      {activeConfig.highlights.map((item) => (
                        <div
                          key={item.title}
                          className={`p-5 rounded-lg border ${toneStyles.card}`}
                        >
                          <p className={`text-xs mb-2 ${toneStyles.muted}`}>{item.meta}</p>
                          <h4 className="font-display font-semibold text-base mb-2">
                            {item.title}
                          </h4>
                          <p className={`text-sm leading-relaxed ${toneStyles.muted}`}>
                            {item.detail}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activePreviewTab === 'contact' && (
                  <div className="max-w-lg mx-auto py-2">
                    <h3 className="font-display text-xl font-bold mb-2">
                      {activeConfig.brandSample} — বার্তা পাঠান
                    </h3>
                    <p className={`text-sm mb-5 ${toneStyles.muted}`}>
                      ক্লায়েন্টরা সরাসরি এই ফর্মের মাধ্যমে আপনার সাথে যোগাযোগ করতে পারবেন।
                    </p>
                    {previewInquirySent ? (
                      <div className={`p-4 rounded-lg border ${toneStyles.card} flex items-center gap-3`}>
                        <Check className="w-5 h-5 text-emerald-600 shrink-0" />
                        <p className="text-sm font-medium">
                          নমুনা বার্তা গৃহীত হয়েছে। প্রকৃত ওয়েবসাইটে এটি সরাসরি আপনার ইমেইল বা ড্যাশবোর্ডে যাবে।
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <input
                          type="text"
                          readOnly
                          value="উদাহরণ: সাইদুর রহমান — নতুন প্রজেক্টের তথ্য"
                          aria-label="নমুনা প্রেরকের নাম"
                          className={`w-full px-3.5 py-2.5 text-sm rounded-lg border ${toneStyles.card}`}
                        />
                        <button
                          type="button"
                          onClick={() => setPreviewInquirySent(true)}
                          className={`px-4 py-2.5 text-sm font-semibold rounded-lg cursor-pointer ${toneStyles.button}`}
                        >
                          নমুনা বার্তা পরীক্ষা করুন
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Apply Blueprint Action Bar */}
        <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-6 border-t border-slate-200">
          <div className="text-sm text-slate-600">
            নির্বাচিত কনফিগারেশন: <strong className="text-slate-900">{activeConfig.label}</strong>
            <span aria-hidden="true" className="mx-2">·</span>
            <strong className="text-slate-900">
              {TONE_OPTIONS.find((t) => t.id === selectedTone)?.label}
            </strong>
          </div>
          <button
            type="button"
            onClick={() => onApplyBlueprint(selectedCategory, selectedTone)}
            className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-800 hover:bg-blue-900 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-800"
          >
            <span>এই স্টাইল দিয়ে আমার ওয়েবসাইট বানান</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
