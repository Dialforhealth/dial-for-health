import { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { ConfirmationResult } from 'firebase/auth';
import { X, AlertCircle, CheckCircle2, Smartphone, Mail } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
}

type AuthTab = 'login' | 'register' | 'phone' | 'reset';

export function AuthModal({ open, onClose }: AuthModalProps) {
  const {
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    sendResetEmail,
    sendPhoneOtp,
    confirmPhoneOtp,
  } = useAuth();
  const { language } = useData();
  const navigate = useNavigate();

  const [tab, setTab] = useState<AuthTab>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('+880');
  const [otpCode, setOtpCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  if (!open) return null;

  const isBn = language === 'bn';

  function redirectByRole(role: 'admin' | 'user') {
    onClose();
    if (role === 'admin') {
      navigate('/admin/dashboard');
    } else {
      navigate('/dashboard');
    }
  }

  function mapAuthError(err: unknown): string {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('auth/operation-not-allowed')) {
      return isBn
        ? 'Firebase Console > Authentication > Sign-in method থেকে এই লগইন পদ্ধতিটি (Email/Password বা Phone) সক্রিয় করুন। Google Sign-In এখনই সক্রিয় আছে।'
        : 'Please enable this sign-in provider (Email/Password or Phone) in Firebase Console > Authentication > Sign-in method. Google Sign-In is active now.';
    }
    if (msg.includes('auth/billing-not-enabled')) {
      return isBn
        ? 'SMS OTP পাঠানোর জন্য Firebase প্রজেক্টে Blaze প্ল্যান অথবা Firebase Console-এ টেস্ট ফোন নম্বর কনফিগার করতে হবে।'
        : 'Real SMS OTP requires Firebase Blaze plan or configured test phone numbers in Firebase Console.';
    }
    if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
      return isBn ? 'ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।' : 'Invalid email or password.';
    }
    if (msg.includes('auth/email-already-in-use')) {
      return isBn ? 'এই ইমেইল দিয়ে ইতিমধ্যে অ্যাকাউন্ট রয়েছে।' : 'An account already exists with this email.';
    }
    return msg;
  }

  async function handleGoogleLogin() {
    setError(null);
    setBusy(true);
    try {
      const role = await loginWithGoogle();
      redirectByRole(role);
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleEmailSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setBusy(true);
    try {
      if (tab === 'login') {
        const role = await loginWithEmail(email, password);
        redirectByRole(role);
      } else if (tab === 'register') {
        if (name.trim().length < 2) {
          throw new Error(isBn ? 'আপনার পূর্ণ নাম লিখুন।' : 'Please enter your full name.');
        }
        if (password.length < 6) {
          throw new Error(
            isBn ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.'
          );
        }
        const role = await registerWithEmail(name, email, password);
        redirectByRole(role);
      } else if (tab === 'reset') {
        await sendResetEmail(email);
        setInfo(
          isBn
            ? 'পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।'
            : 'Password reset link has been sent to your email.'
        );
      }
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleSendOtp(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    if (!/^\+\d{10,15}$/.test(phone.trim())) {
      setError(
        isBn
          ? 'আন্তর্জাতিক ফরম্যাটে সঠিক নম্বর দিন (যেমন: +8801712345678)।'
          : 'Enter a valid international phone number (e.g., +8801712345678).'
      );
      return;
    }
    setBusy(true);
    try {
      const result = await sendPhoneOtp(phone, 'recaptcha-container');
      setConfirmationResult(result);
      setInfo(
        isBn
          ? 'আপনার মোবাইলে SMS-এ পাঠানো ৬ ডিজিটের ভেরিফিকেশন কোড লিখুন।'
          : 'Enter the 6-digit SMS verification code sent to your mobile.'
      );
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleVerifyOtp(e: FormEvent) {
    e.preventDefault();
    if (!confirmationResult) return;
    setError(null);
    setBusy(true);
    try {
      const role = await confirmPhoneOtp(confirmationResult, otpCode, name);
      redirectByRole(role);
    } catch (err) {
      setError(mapAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2
              id="auth-modal-title"
              className="font-display text-lg font-bold text-slate-900 dark:text-white"
            >
              Dial for Health — {isBn ? 'অ্যাকাউন্ট প্রবেশ' : 'Account Access'}
            </h2>
            <p className="text-xs text-slate-500">
              {isBn ? 'নিরাপদ Firebase Authentication' : 'Secured by Firebase Authentication'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-9 h-9 inline-flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Google Sign-In Primary Option */}
          <button
            type="button"
            disabled={busy}
            onClick={handleGoogleLogin}
            className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>{isBn ? 'Google অ্যাকাউন্ট দিয়ে চালিয়ে যান' : 'Continue with Google'}</span>
          </button>

          <div className="relative flex items-center justify-center text-xs text-slate-400">
            <span className="w-full border-t border-slate-200 dark:border-slate-800" />
            <span className="px-3 bg-white dark:bg-slate-900 whitespace-nowrap">
              {isBn ? 'অথবা ইমেইল / মোবাইল OTP' : 'OR Email / Mobile OTP'}
            </span>
            <span className="w-full border-t border-slate-200 dark:border-slate-800" />
          </div>

          {/* Method Tabs */}
          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium">
            <button
              type="button"
              onClick={() => {
                setTab('login');
                setError(null);
              }}
              className={`py-2 rounded-md cursor-pointer ${
                tab === 'login' || tab === 'reset'
                  ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Mail className="w-3.5 h-3.5 inline mr-1" />
              {isBn ? 'লগইন' : 'Login'}
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('register');
                setError(null);
              }}
              className={`py-2 rounded-md cursor-pointer ${
                tab === 'register'
                  ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {isBn ? 'নিবন্ধন' : 'Register'}
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('phone');
                setError(null);
              }}
              className={`py-2 rounded-md cursor-pointer ${
                tab === 'phone'
                  ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 inline mr-1" />
              {isBn ? 'SMS OTP' : 'SMS OTP'}
            </button>
          </div>

          {error && (
            <div
              role="alert"
              className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-xs text-red-800 dark:text-red-300"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {info && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-300">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{info}</span>
            </div>
          )}

          {tab !== 'phone' ? (
            <form onSubmit={handleEmailSubmit} className="space-y-3.5">
              {tab === 'register' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {isBn ? 'পূর্ণ নাম' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={isBn ? 'রোগীর নাম লিখুন' : 'Enter your full name'}
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {isBn ? 'ইমেইল ঠিকানা' : 'Email Address'}
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>

              {tab !== 'reset' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {isBn ? 'পাসওয়ার্ড' : 'Password'}
                  </label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={busy}
                className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                {busy
                  ? isBn
                    ? 'অপেক্ষা করুন...'
                    : 'Please wait...'
                  : tab === 'login'
                  ? isBn
                    ? 'লগইন করুন'
                    : 'Sign In'
                  : tab === 'register'
                  ? isBn
                    ? 'নতুন অ্যাকাউন্ট তৈরি করুন'
                    : 'Create Account'
                  : isBn
                  ? 'রিসেট লিংক পাঠান'
                  : 'Send Reset Link'}
              </button>

              {tab === 'login' && (
                <button
                  type="button"
                  onClick={() => setTab('reset')}
                  className="text-xs text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                >
                  {isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                </button>
              )}
              {tab === 'reset' && (
                <button
                  type="button"
                  onClick={() => setTab('login')}
                  className="text-xs text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                >
                  {isBn ? 'লগইনে ফিরে যান' : 'Back to Login'}
                </button>
              )}
            </form>
          ) : (
            <div className="space-y-3.5">
              {!confirmationResult ? (
                <form onSubmit={handleSendOtp} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {isBn ? 'পূর্ণ নাম (ঐচ্ছিক)' : 'Full Name (Optional)'}
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={isBn ? 'আপনার নাম' : 'Your name'}
                      className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {isBn ? 'বাংলাদেশি মোবাইল নম্বর (+880...)' : 'Mobile Number (+880...)'}
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+8801712345678"
                      className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 tabular-nums"
                    />
                  </div>
                  <div id="recaptcha-container" />
                  <button
                    type="submit"
                    disabled={busy}
                    className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
                  >
                    {busy
                      ? isBn
                        ? 'OTP পাঠানো হচ্ছে...'
                        : 'Sending OTP...'
                      : isBn
                      ? 'SMS OTP পাঠান'
                      : 'Send Real SMS OTP'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {isBn ? '৬ ডিজিটের OTP কোড' : '6-Digit OTP Code'}
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      placeholder="123456"
                      className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 font-mono-tabular"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={busy}
                    className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                  >
                    {busy ? (isBn ? 'যাচাই হচ্ছে...' : 'Verifying...') : isBn ? 'OTP যাচাই করুন' : 'Verify OTP'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmationResult(null)}
                    className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                  >
                    {isBn ? 'নম্বর পরিবর্তন করুন' : 'Change mobile number'}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
