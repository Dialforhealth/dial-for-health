import { Link } from 'react-router-dom';
import { PhoneCall, Mail, MapPin } from 'lucide-react';
import { useData } from '../contexts/DataContext';

export function Footer() {
  const { language, appSettings } = useData();
  const isBn = language === 'bn';

  return (
    <footer className="bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 pt-14 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-10 border-b border-slate-200 dark:border-slate-800">
          {/* Brand & About */}
          <div>
            <Link
              to="/"
              className="font-display text-xl font-bold text-blue-800 dark:text-blue-400"
            >
              {appSettings.siteName}
            </Link>
            <p className="text-xs font-medium text-blue-700 dark:text-blue-300 mt-1">
              {appSettings.tagline}
            </p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-3 leading-relaxed">
              {appSettings.aboutContent}
            </p>
          </div>

          {/* Important Links */}
          <div>
            <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100 mb-3">
              {isBn ? 'গুরুত্বপূর্ণ লিংক' : 'Important Links'}
            </h3>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <li>
                <Link to="/doctors" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'বিশেষজ্ঞ ডাক্তার ডিরেক্টরি' : 'Doctor Directory'}
                </Link>
              </li>
              <li>
                <Link to="/hospitals" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'হাসপাতাল ডিরেক্টরি' : 'Hospital Directory'}
                </Link>
              </li>
              <li>
                <Link to="/diagnostic-centers" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'ডায়াগনস্টিক সেন্টার' : 'Diagnostic Centers'}
                </Link>
              </li>
              <li>
                <Link to="/appointments" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'অনলাইন অ্যাপয়েন্টমেন্ট' : 'Book Appointment'}
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'সচরাচর জিজ্ঞাসা (FAQ)' : 'FAQ'}
                </Link>
              </li>
            </ul>
          </div>

          {/* Medical Services & Legal */}
          <div>
            <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100 mb-3">
              {isBn ? 'স্বাস্থ্যসেবা ও নীতিমালা' : 'Services & Policies'}
            </h3>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <li>
                <Link to="/about" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'আমাদের সম্পর্কে' : 'About Us'}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'সাপোর্ট ও যোগাযোগ' : 'Contact Support'}
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'গোপনীয়তা নীতি (Privacy Policy)' : 'Privacy Policy'}
                </Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'ব্যবহারের শর্তাবলি (Terms)' : 'Terms & Conditions'}
                </Link>
              </li>
              <li>
                <Link to="/admin/login" className="hover:text-blue-700 dark:hover:text-blue-400">
                  {isBn ? 'অ্যাডমিন প্যানেল' : 'Admin Portal'}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact & Emergency */}
          <div>
            <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-slate-100 mb-3">
              {isBn ? 'যোগাযোগ ও জরুরি সহায়তা' : 'Contact & Emergency'}
            </h3>
            <div className="space-y-2.5 text-sm text-slate-600 dark:text-slate-400">
              <p className="flex items-center gap-2 tabular-nums">
                <PhoneCall className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0" />
                <span>
                  {isBn ? 'হেল্পলাইন: ' : 'Support: '}
                  {appSettings.supportPhone}
                </span>
              </p>
              <p className="flex items-center gap-2 tabular-nums text-red-700 dark:text-red-400 font-medium">
                <PhoneCall className="w-4 h-4 shrink-0" />
                <span>
                  {isBn ? 'জরুরি সেবা: ' : 'Emergency: '}
                  {appSettings.emergencyHotline}
                </span>
              </p>
              {appSettings.supportEmail && (
                <p className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0" />
                  <span>{appSettings.supportEmail}</span>
                </p>
              )}
              {appSettings.address && (
                <p className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
                  <span>{appSettings.address}</span>
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <p>
            © ২০২৬ Dial for Health Bangladesh · {isBn ? 'সর্বস্বত্ব সংরক্ষিত' : 'All Rights Reserved'}
          </p>
          <div className="flex items-center gap-4">
            {appSettings.whatsappNumber && (
              <a
                href={`https://wa.me/${appSettings.whatsappNumber.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-blue-700 dark:hover:text-blue-400"
              >
                WhatsApp Support
              </a>
            )}
            <a href="/sitemap.xml" className="hover:text-blue-700 dark:hover:text-blue-400">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
