/* Firebase Cloud Messaging Service Worker for Dial for Health */
self.addEventListener('push', function (event) {
  let payload = { title: 'Dial for Health', body: 'আপনার একটি নতুন স্বাস্থ্য আপডেট রয়েছে।' };
  try {
    if (event.data) {
      const parsed = event.data.json();
      payload = {
        title: parsed.notification?.title || parsed.data?.title || payload.title,
        body: parsed.notification?.body || parsed.data?.body || payload.body,
      };
    }
  } catch (e) {
    // Fallback to default message
  }

  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      tag: 'dial-for-health-alert',
    })
  );
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  event.waitUntil(clients.openWindow('/dashboard'));
});
